import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  Activity as ActivityIcon, ArrowDownToLine, ArrowLeftRight, ArrowUpRight,
  BriefcaseBusiness, Building2, CarFront, ChevronRight, Clock3, Coins,
  CalendarDays, Check, KeyRound, Gauge, Smartphone,
  ShoppingBag, Heart, Bitcoin, Contact, MessagesSquare, Map,
  Store, Settings, ChevronLeft, Minimize2, Wifi, BatteryFull,
  CircleHelp,
  HandCoins, HeartPulse, House, Landmark, LockKeyhole, LogOut, MapPin, Menu,
  ShieldAlert, Sparkles, UserRound, Wallet, X, Zap,
} from 'lucide-react';
import {
  getGetCurrentPlayerQueryKey, getGetGameDashboardQueryKey, getListJobsQueryKey,
  getGetGarageQueryKey, getListVehiclesQueryKey,
  useCreateBankTransaction, useGetCurrentPlayer, useGetGameDashboard, useListJobs,
  useGetGarage, useListVehicles, usePurchaseVehicle, useSetActiveVehicle,
  useLoginPlayer, useLogoutPlayer, useRegisterPlayer, useWorkJobShift,
} from '@workspace/api-client-react';
import type { Activity as GameActivity, DealershipVehicle, FeatureStatus, Job, Player, PlayerVehicle } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Link, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } },
});

const cash = (amount: number) => new Intl.NumberFormat('en-US', {
  style: 'currency', currency: 'USD', maximumFractionDigits: 0,
}).format(amount);

const timeAgo = (value: string) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recently';
  const minutes = Math.max(0, Math.floor((Date.now() - date.getTime()) / 60000));
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes} min ago`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)} hr ago`;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
};

function serverMessage(error: unknown, fallback = 'Something went wrong. Try again.') {
  if (error && typeof error === 'object') {
    const item = error as {
      message?: string;
      data?: { error?: string; message?: string };
      payload?: { error?: string; message?: string };
      response?: { data?: { error?: string; message?: string } };
    };
    return item.data?.error || item.data?.message || item.payload?.error || item.payload?.message || item.response?.data?.error || item.response?.data?.message || item.message || fallback;
  }
  return fallback;
}

function LoadingScreen({ label = 'Checking your session' }: { label?: string }) {
  return (
    <main className="min-h-[100dvh] flex items-center justify-center px-5" aria-label={label} data-testid="status-loading">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-7 shadow-sm">
        <div className="mb-6 flex items-center gap-3">
          <div className="h-11 w-11 animate-pulse rounded-2xl bg-muted" />
          <div className="space-y-2"><div className="h-3 w-32 animate-pulse rounded bg-muted" /><div className="h-3 w-20 animate-pulse rounded bg-muted" /></div>
        </div>
        <div className="h-9 w-3/4 animate-pulse rounded-lg bg-muted" />
        <div className="mt-4 h-4 w-full animate-pulse rounded bg-muted" />
        <div className="mt-2 h-4 w-4/5 animate-pulse rounded bg-muted" />
        <p className="mt-6 text-sm text-muted-foreground">{label}…</p>
      </div>
    </main>
  );
}

function Mark({ small = false }: { small?: boolean }) {
  return (
    <span className={`grid shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground ${small ? 'h-9 w-9' : 'h-12 w-12'}`}>
      <span className={`font-display font-bold leading-none tracking-tight ${small ? 'text-xl' : 'text-3xl'}`}>RL</span>
    </span>
  );
}

function AuthPage() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { data: player, isLoading } = useGetCurrentPlayer({
    query: { queryKey: getGetCurrentPlayerQueryKey(), retry: false },
  });
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState('');
  const login = useLoginPlayer();
  const register = useRegisterPlayer();
  const pending = login.isPending || register.isPending;

  useEffect(() => {
    if (player) navigate('/dashboard');
  }, [player, navigate]);
  if (isLoading) return <LoadingScreen />;

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError('');
    if (username.trim().length < 3) {
      setFormError('Your handle needs at least 3 characters.');
      return;
    }
    if (mode === 'register' && password.length < 10) {
      setFormError('Use at least 10 characters for your password.');
      return;
    }
    const variables = { data: { username: username.trim(), password } };
    const mutation = mode === 'login' ? login : register;
    mutation.mutate(variables, {
      onSuccess: (signedInPlayer) => {
        queryClient.setQueryData(getGetCurrentPlayerQueryKey(), signedInPlayer);
        queryClient.removeQueries({ queryKey: getGetGameDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetGameDashboardQueryKey() });
        navigate('/dashboard');
      },
      onError: (error) => setFormError(serverMessage(error, mode === 'login' ? 'Could not sign in.' : 'Could not create your account.')),
    });
  };

  return (
    <main className="shell-noise min-h-[100dvh] p-4 sm:p-6 lg:p-10" data-testid="page-auth">
      <div className="mx-auto grid min-h-[calc(100dvh-2rem)] max-w-6xl overflow-hidden rounded-[2rem] border border-border bg-card shadow-[0_22px_70px_-36px_rgba(36,45,48,.32)] sm:min-h-[calc(100dvh-3rem)] lg:grid-cols-[1.04fr_.96fr]">
        <section className="relative flex min-h-[320px] flex-col justify-between overflow-hidden bg-[#20323a] p-7 text-[#f3eee3] sm:p-10 lg:min-h-full lg:p-14">
          <div className="absolute -right-24 top-24 h-72 w-72 rounded-full border border-white/10" />
          <div className="absolute -right-8 top-40 h-40 w-40 rounded-full border border-white/10" />
          <div className="absolute bottom-20 right-10 h-24 w-24 rotate-12 border border-[#db633f]/50" />
          <div className="relative z-10 flex items-center gap-3"><Mark /><span className="font-display text-xl font-bold uppercase tracking-[.12em]">Real Life Online</span></div>
          <div className="relative z-10 max-w-xl py-10 lg:py-16">
            <p className="mb-4 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[.23em] text-[#e4bc60]"><span className="h-px w-7 bg-[#e4bc60]" />One city. Your call.</p>
            <h1 className="font-display text-6xl font-bold uppercase leading-[.88] tracking-tight sm:text-7xl lg:text-[6.5rem]">Make your<br />own <span className="text-[#e4bc60]">way.</span></h1>
            <p className="mt-7 max-w-md text-base leading-7 text-[#d2d5d0] sm:text-lg">Clock in, stack your money, and decide what kind of life this city gets from you.</p>
          </div>
          <div className="relative z-10 flex items-center gap-3 border-t border-white/15 pt-5 text-xs text-[#c2cbc8]">
            <MapPin size={15} className="text-[#e4bc60]" /> <span>Northside · 06:42 AM</span><span className="ml-auto font-mono uppercase tracking-widest">Single-player story</span>
          </div>
          <div className="absolute bottom-0 right-0 h-2 w-2/5 bg-primary" />
        </section>
        <section className="flex items-center justify-center px-6 py-9 sm:px-12 lg:px-16">
          <div className="w-full max-w-md">
            <div className="mb-8 lg:hidden"><Mark small /></div>
            <div className="mb-8">
              <p className="font-mono text-[11px] uppercase tracking-[.2em] text-primary">Your next chapter starts here</p>
              <h2 className="mt-2 font-display text-4xl font-bold uppercase tracking-tight sm:text-5xl" data-testid="text-auth-heading">{mode === 'login' ? 'Back on the block.' : 'Claim your corner.'}</h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{mode === 'login' ? 'Pick up where the city left you.' : 'Build a name, one honest shift at a time.'}</p>
            </div>
            <div className="mb-6 grid grid-cols-2 rounded-xl bg-muted p-1" role="tablist" aria-label="Account access">
              <button type="button" role="tab" aria-selected={mode === 'login'} data-testid="tab-login" onClick={() => { setMode('login'); setFormError(''); }} className={`rounded-lg px-4 py-2.5 text-sm font-semibold transition ${mode === 'login' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>Sign in</button>
              <button type="button" role="tab" aria-selected={mode === 'register'} data-testid="tab-register" onClick={() => { setMode('register'); setFormError(''); }} className={`rounded-lg px-4 py-2.5 text-sm font-semibold transition ${mode === 'register' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>Create account</button>
            </div>
            <form onSubmit={submit} className="space-y-5">
              <label className="block">
                <span className="mb-2 block text-sm font-semibold">Player handle</span>
                <span className="relative block">
                  <UserRound size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input autoComplete="username" required minLength={3} maxLength={20} value={username} onChange={(event) => setUsername(event.target.value)} placeholder="Your handle" data-testid="input-username" className="h-12 w-full rounded-xl border border-input bg-background pl-10 pr-4 text-sm outline-none transition placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/15" />
                </span>
              </label>
              <label className="block">
                <span className="mb-2 flex items-center justify-between text-sm font-semibold"><span>Password</span>{mode === 'register' && <span className="font-normal text-muted-foreground">10 characters minimum</span>}</span>
                <span className="relative block">
                  <LockKeyhole size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={mode === 'register' ? 10 : 1} maxLength={72} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Your password" data-testid="input-password" className="h-12 w-full rounded-xl border border-input bg-background pl-10 pr-4 text-sm outline-none transition placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/15" />
                </span>
              </label>
              {formError && <div role="alert" data-testid="status-auth-error" className="rounded-xl border border-destructive/25 bg-destructive/5 px-4 py-3 text-sm leading-5 text-destructive">{formError}</div>}
              <button type="submit" disabled={pending} data-testid="button-auth-submit" className="group flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 font-semibold text-primary-foreground transition hover:bg-[#b7442d] disabled:cursor-wait disabled:opacity-65">
                {pending ? <><span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent" />{mode === 'login' ? 'Signing in…' : 'Creating your account…'}</> : <>{mode === 'login' ? 'Enter the city' : 'Start your story'}<ArrowUpRight size={17} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></>}
              </button>
            </form>
            <p className="mt-6 flex items-start gap-2 text-xs leading-5 text-muted-foreground"><ShieldAlert size={14} className="mt-0.5 shrink-0" />Your account is saved securely. We never store your password in this browser.</p>
          </div>
        </section>
      </div>
    </main>
  );
}

const navItems = [
  { href: '/dashboard', label: 'City', icon: Building2 },
  { href: '/phone', label: 'Phone', icon: Smartphone },
  { href: '/jobs', label: 'Work', icon: BriefcaseBusiness },
  { href: '/bank', label: 'Bank', icon: Landmark },
  { href: '/dealership', label: 'Vehicle Dealership', icon: CarFront },
  { href: '/garage', label: 'My Garage', icon: Gauge },
];

function AppShell({ children, player }: { children: ReactNode; player: Player }) {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const logout = useLogoutPlayer();
  const lastPlayerId = useRef<number | null>(null);
  useEffect(() => {
    if (lastPlayerId.current !== null && lastPlayerId.current !== player.id) {
      queryClient.removeQueries({ queryKey: getGetGameDashboardQueryKey() });
      queryClient.removeQueries({ queryKey: getListJobsQueryKey() });
      queryClient.removeQueries({ queryKey: getListVehiclesQueryKey() });
      queryClient.removeQueries({ queryKey: getGetGarageQueryKey() });
    }
    lastPlayerId.current = player.id;
  }, [player.id, queryClient]);
  const onLogout = () => logout.mutate(undefined, {
    onSuccess: () => {
      queryClient.clear();
      navigate('/');
    },
    onError: () => {
      queryClient.clear();
      navigate('/');
    },
  });
  const [mobileMenu, setMobileMenu] = useState(false);
  const [path] = useLocation();
  return (
    <div className="shell-noise min-h-[100dvh]">
      <header className="sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[70px] max-w-[1440px] items-center gap-7 px-4 sm:px-7">
          <Link href="/dashboard" className="flex min-w-fit items-center gap-2.5" aria-label="Real Life Online home" data-testid="link-brand-home">
            <Mark small /><span className="hidden font-display text-xl font-bold uppercase leading-[.82] tracking-wide sm:inline">Real Life<br /><span className="text-primary">Online</span></span>
          </Link>
          <div className="hidden h-8 w-px bg-border md:block" />
          <div className="hidden items-center gap-1 xl:flex" aria-label="Main navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = path === item.href;
              return <Link href={item.href} key={item.href} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`} className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-semibold transition ${active ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}><Icon size={16} />{item.label}</Link>;
            })}
          </div>
          <button type="button" aria-label={mobileMenu ? 'Close navigation' : 'Open navigation'} aria-expanded={mobileMenu} data-testid="button-mobile-menu" onClick={() => setMobileMenu(!mobileMenu)} className="ml-auto grid h-10 w-10 place-items-center rounded-xl border border-border text-foreground xl:hidden">{mobileMenu ? <X size={19} /> : <Menu size={19} />}</button>
          <div className="ml-auto hidden items-center gap-3 md:flex">
            <div className="text-right"><p className="text-sm font-bold leading-4" data-testid="text-player-handle">{player.username}</p><p className="mt-1 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground">Level {player.level} · Player</p></div>
            <div className="grid h-10 w-10 place-items-center rounded-full border border-border bg-secondary font-display text-lg font-bold text-secondary-foreground" aria-hidden="true">{player.username.slice(0, 1).toUpperCase()}</div>
            <button type="button" onClick={onLogout} disabled={logout.isPending} aria-label="Sign out" title="Sign out" data-testid="button-logout" className="ml-1 grid h-9 w-9 place-items-center rounded-lg text-muted-foreground transition hover:bg-muted hover:text-foreground disabled:opacity-50"><LogOut size={17} /></button>
          </div>
        </div>
         {mobileMenu && <div className="border-t border-border bg-card px-4 py-3 xl:hidden">{navItems.map((item) => { const Icon = item.icon; return <Link key={item.href} href={item.href} onClick={() => setMobileMenu(false)} data-testid={`link-mobile-${item.label.toLowerCase().replaceAll(' ', '-')}`} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold ${path === item.href ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground'}`}><Icon size={17} />{item.label}<ChevronRight size={15} className="ml-auto" /></Link>; })}<button type="button" onClick={onLogout} data-testid="button-mobile-logout" className="mt-2 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-muted-foreground"><LogOut size={17} />Sign out</button></div>}
      </header>
      <main className="mx-auto max-w-[1440px] px-4 pb-28 pt-7 sm:px-7 sm:pt-10 md:pb-12">{children}</main>
       <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-border bg-card/95 px-1 pb-[max(.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur md:hidden" aria-label="Mobile main navigation">
          {navItems.filter((item) => item.href !== '/dealership' && item.href !== '/garage').map((item) => { const Icon = item.icon; const active = path === item.href || (item.href === '/phone' && path.startsWith('/phone/')); return <Link href={item.href} key={item.href} aria-label={item.label} data-testid={`link-bottom-${item.label.toLowerCase().replaceAll(' ', '-')}`} className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-0.5 text-[9px] font-semibold leading-[1.05] ${active ? 'text-primary' : 'text-muted-foreground'}`}><Icon size={19} strokeWidth={active ? 2.5 : 1.8} /><span className="w-full text-center">{item.label}</span></Link>; })}
      </nav>
    </div>
  );
}

function SectionHeading({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><p className="font-mono text-[10px] font-medium uppercase tracking-[.2em] text-primary">{eyebrow}</p><h1 className="mt-1 font-display text-4xl font-bold uppercase leading-none tracking-tight sm:text-5xl" data-testid="text-page-heading">{title}</h1>{detail && <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{detail}</p>}</div>{action}</div>;
}

function MetricCard({ label, value, suffix, icon: Icon, tone = 'plain', testId }: { label: string; value: string | number; suffix?: string; icon: typeof Wallet; tone?: 'plain' | 'warm'; testId: string }) {
  return <div className={`rounded-2xl border p-4 sm:p-5 ${tone === 'warm' ? 'border-primary/15 bg-[#f6e4d8]' : 'border-border bg-card'}`} data-testid={testId}><div className="flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-[.15em] text-muted-foreground">{label}</span><Icon size={17} className={tone === 'warm' ? 'text-primary' : 'text-muted-foreground'} /></div><div className="mt-3 flex items-baseline gap-1.5"><strong className="font-display text-3xl font-bold leading-none tracking-tight">{value}</strong>{suffix && <span className="text-xs text-muted-foreground">{suffix}</span>}</div></div>;
}

function QueryError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <div role="alert" className="rounded-2xl border border-destructive/25 bg-card p-6" data-testid="status-query-error"><p className="font-semibold text-destructive">{message}</p><button type="button" onClick={onRetry} data-testid="button-retry" className="mt-4 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Try again</button></div>;
}

function ActivityFeed({ activities }: { activities: GameActivity[] }) {
  return <section className="rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="activity-heading">
    <div className="mb-5 flex items-center justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.17em] text-muted-foreground">City keeps moving</p><h2 id="activity-heading" className="mt-1 font-display text-2xl font-bold uppercase">Recent activity</h2></div><ActivityIcon size={19} className="text-primary" /></div>
    {activities.length === 0 ? <div className="rounded-xl border border-dashed border-border bg-background p-5 text-sm text-muted-foreground" data-testid="empty-activities">Nothing on your record yet. Your first shift will change that.</div> : <div className="divide-y divide-border">{activities.slice(0, 6).map((activity) => <div key={activity.id} data-testid={`row-activity-${activity.id}`} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground"><Coins size={16} /></span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{activity.description}</p><p className="mt-0.5 font-mono text-[10px] text-muted-foreground">{timeAgo(activity.createdAt)}</p></div>{activity.amount !== null && <strong className="font-mono text-sm text-[#36715f]">{activity.amount >= 0 ? '+' : '−'}{cash(Math.abs(activity.amount))}</strong>}</div>)}</div>}
  </section>;
}

const futureFeatureDefaults: FeatureStatus[] = [
  { id: 'vehicles', title: 'Vehicles', status: 'available', description: 'Browse the dealership and manage your vehicles.' },
  { id: 'properties', title: 'Properties', status: 'coming_soon', description: 'Find a place to call yours and build your life.' },
  { id: 'businesses', title: 'Businesses', status: 'coming_soon', description: 'Turn a side hustle into something bigger.' },
  { id: 'city-hall', title: 'City hall', status: 'coming_soon', description: 'Influence the rules that shape your neighborhood.' },
  { id: 'police-crime', title: 'Crime & justice', status: 'coming_soon', description: 'A deeper risk-and-reputation system is on the way.' },
];
const forceUpcoming = /property|business|police|crime|government|city hall/i;
function FeatureBoard({ features }: { features: FeatureStatus[] }) {
  const merged = useMemo(() => {
    const all = [...features];
    futureFeatureDefaults.forEach((entry) => { if (!all.some((feature) => feature.id === entry.id || feature.title.toLowerCase() === entry.title.toLowerCase())) all.push(entry); });
    return all.map((feature) => {
      if (/vehicle/i.test(`${feature.id} ${feature.title}`)) return { ...feature, status: 'available' as const };
      return forceUpcoming.test(`${feature.id} ${feature.title}`) ? { ...feature, status: 'coming_soon' as const } : feature;
    });
  }, [features]);
  return <section aria-labelledby="feature-heading"><div className="mb-4 flex items-end justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.17em] text-muted-foreground">More of the city is coming</p><h2 id="feature-heading" className="mt-1 font-display text-2xl font-bold uppercase">On the horizon</h2></div><span className="rounded-full border border-border px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">Early access</span></div>
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{merged.map((feature, index) => { const Icon = [CarFront, House, BriefcaseBusiness, ShieldAlert, Building2][index % 5]; return <article key={feature.id} data-testid={`card-feature-${feature.id}`} className="group rounded-2xl border border-border bg-card p-4 transition hover:-translate-y-0.5 hover:border-primary/30"><div className="flex items-start justify-between"><span className="grid h-9 w-9 place-items-center rounded-xl bg-muted text-muted-foreground"><Icon size={17} /></span><span data-testid={`status-feature-${feature.id}`} className="rounded-full bg-muted px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{feature.status === 'available' ? 'Available' : 'Coming soon'}</span></div><h3 className="mt-3 font-semibold">{feature.title}</h3><p className="mt-1 text-xs leading-5 text-muted-foreground">{feature.description}</p></article>; })}</div>
  </section>;
}

function DashboardPage({ player }: { player: Player }) {
  const dashboard = useGetGameDashboard({ query: { enabled: !!player.id, queryKey: getGetGameDashboardQueryKey() } });
  const data = dashboard.data;
  if (dashboard.isLoading) return <DashboardSkeleton />;
  if (dashboard.error || !data) return <QueryError message={serverMessage(dashboard.error, 'Your city could not load right now.')} onRetry={() => void dashboard.refetch()} />;
  const gamePlayer = data.player;
  return <div className="page-enter space-y-7" data-testid="page-dashboard">
    <SectionHeading eyebrow="Your city · Your life in progress" title={`Welcome back, ${gamePlayer.username}.`} detail="The next move is yours. Check your standing, then get back out there." />
    <section className="dashboard-overview grid gap-5 lg:grid-cols-[1.1fr_.9fr]" aria-label="Player overview">
      <div className="relative overflow-hidden rounded-[1.75rem] border border-primary/20 bg-[#172027] p-6 sm:p-8" data-testid="panel-player-summary">
        <div className="absolute -right-16 -top-20 h-64 w-64 rounded-full border border-primary/15" /><div className="absolute right-12 top-4 h-40 w-40 rounded-full border border-primary/10" />
        <div className="relative flex items-start justify-between gap-4">
          <div><p className="font-mono text-[10px] uppercase tracking-[.22em] text-primary">Character file</p><h2 className="mt-2 font-display text-5xl font-bold uppercase leading-none sm:text-6xl" data-testid="text-dashboard-player">{gamePlayer.username}</h2><p className="mt-3 text-sm text-muted-foreground">{gamePlayer.currentJob || 'Between jobs'} <span className="px-2 text-primary">/</span> Level {gamePlayer.level}</p></div>
          <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-primary/30 bg-primary/10 font-display text-2xl font-bold text-primary" aria-hidden="true">{gamePlayer.username.slice(0, 1).toUpperCase()}</div>
        </div>
        <Link href="/phone" data-testid="button-open-phone" className="relative mt-8 flex min-h-14 w-full items-center justify-between rounded-xl bg-primary px-5 font-semibold text-primary-foreground transition hover:brightness-110 sm:w-auto sm:min-w-[230px]"><span className="flex items-center gap-3"><Smartphone size={19} />Open your phone</span><ArrowUpRight size={18} /></Link>
        <p className="relative mt-3 font-mono text-[9px] uppercase tracking-[.18em] text-muted-foreground">Your central line to the city</p>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2" data-testid="section-player-stats">
        {[
          { label: 'Cash', value: cash(gamePlayer.cash), icon: Wallet },
          { label: 'Bank', value: cash(gamePlayer.bankBalance), icon: Landmark },
          { label: 'Experience', value: gamePlayer.experience.toLocaleString(), icon: Sparkles },
          { label: 'Reputation', value: gamePlayer.reputation, icon: ActivityIcon },
        ].map((stat) => { const Icon = stat.icon; return <div key={stat.label} data-testid={`stat-${stat.label.toLowerCase()}`} className="rounded-2xl border border-border bg-card p-4 sm:p-5"><div className="flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">{stat.label}</span><Icon size={17} className="text-primary" /></div><p className="mt-4 break-words font-display text-3xl font-bold leading-none sm:text-4xl">{stat.value}</p>{stat.label === 'Cash' || stat.label === 'Bank' ? <p className="mt-2 text-[10px] text-muted-foreground">Available balance</p> : null}</div>; })}
      </div>
    </section>
    <section className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]">
      <div className="rounded-2xl border border-border bg-card p-5 sm:p-6" data-testid="section-character-condition">
        <div className="mb-5"><p className="font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">On the street</p><h2 className="mt-1 font-display text-2xl font-bold uppercase">Current standing</h2></div>
        <div className="space-y-5"><ProgressLine label="Health" value={gamePlayer.health} icon={HeartPulse} color="bg-[#72aa88]" testId="meter-health" /><ProgressLine label="Energy" value={gamePlayer.energy} icon={Zap} color="bg-primary" testId="meter-energy" /><ProgressLine label="Wanted level" value={gamePlayer.wantedLevel} max={5} icon={ShieldAlert} color="bg-[#b96d5c]" testId="meter-wanted" /></div>
      </div>
      <section className="rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="activity-heading">
        <div className="mb-4 flex items-end justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">Latest eight mixed events</p><h2 id="activity-heading" className="mt-1 font-display text-2xl font-bold uppercase">City notifications</h2></div><ActivityIcon size={19} className="text-primary" /></div>
        {!data.activities?.length ? <div className="rounded-xl border border-dashed border-border bg-background p-5 text-sm text-muted-foreground" data-testid="empty-activities">No activity yet. Your first move will show up here.</div> : <div className="divide-y divide-border">{data.activities.slice(0, 5).map((activity) => <div key={activity.id} data-testid={`row-activity-${activity.id}`} className="flex items-center gap-3 py-3 first:pt-1 last:pb-0"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground"><Coins size={16} /></span><div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{activity.description}</p><p className="mt-0.5 font-mono text-[10px] text-muted-foreground">{timeAgo(activity.createdAt)}</p></div>{activity.amount !== null && <strong className="shrink-0 font-mono text-xs text-primary">{activity.amount >= 0 ? '+' : '−'}{cash(Math.abs(activity.amount))}</strong>}</div>)}</div>}
        <p className="mt-4 border-t border-border pt-3 text-[10px] leading-4 text-muted-foreground">A snapshot of recent city activity, not a complete account history.</p>
      </section>
    </section>
    <section className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6" data-testid="panel-next-shift">
      <div><p className="font-mono text-[10px] uppercase tracking-[.17em] text-primary">Earn your next step</p><h2 className="mt-1 font-display text-2xl font-bold uppercase">Work is waiting.</h2><p className="mt-1 text-sm text-muted-foreground">Browse the available shifts and decide what your time is worth.</p></div>
      <Link href="/jobs" data-testid="link-all-jobs" className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-primary/30 px-5 text-sm font-semibold text-primary transition hover:bg-primary/10"><BriefcaseBusiness size={17} />View jobs<ChevronRight size={16} /></Link>
    </section>
  </div>;
}

function ProgressLine({ label, value, max = 100, icon: Icon, color, testId }: { label: string; value: number; max?: number; icon: typeof Wallet; color: string; testId: string }) {
  const percentage = Math.min(100, Math.max(0, max === 100 ? value : (value / max) * 100));
  return <div data-testid={testId}><div className="mb-2 flex items-center justify-between text-xs"><span className="flex items-center gap-2 text-[#d4dbd7]"><Icon size={14} />{label}</span><strong className="font-mono">{value}{max !== 100 ? ` / ${max}` : '%'}</strong></div><div className="h-1.5 overflow-hidden rounded-full bg-white/15"><div className={`h-full rounded-full ${color} transition-[width] duration-500`} style={{ width: `${percentage}%` }} /></div></div>;
}

function QuickJob({ job, player }: { job: Job; player: Player }) {
  const queryClient = useQueryClient();
  const work = useWorkJobShift();
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const canWork = player.energy >= job.energyCost;
  return <article className="rounded-2xl border border-border bg-card p-4 transition hover:border-primary/30" data-testid={`card-quick-job-${job.id}`}><div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold">{job.title}</h3><p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin size={12} />{job.district}</p></div><span className="rounded-lg bg-[#e5eee8] px-2.5 py-1.5 font-mono text-xs font-medium text-[#37644f]">{cash(job.salary)}</span></div><p className="mt-3 line-clamp-2 text-xs leading-5 text-muted-foreground">{job.description}</p><div className="mt-4 flex items-center justify-between gap-3"><span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground"><Zap size={12} />{job.energyCost} energy</span><button type="button" disabled={!canWork || work.isPending} data-testid={`button-work-quick-${job.id}`} onClick={() => { setError(''); setMessage(''); work.mutate({ jobId: job.id }, { onSuccess: (result) => { setMessage(`Shift complete · ${cash(result.salary)} earned`); queryClient.invalidateQueries({ queryKey: getGetGameDashboardQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetCurrentPlayerQueryKey() }); }, onError: (issue) => setError(serverMessage(issue, 'This shift could not be completed.')) }); }} className="rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground transition hover:bg-[#b7442d] disabled:cursor-not-allowed disabled:opacity-45">{work.isPending ? 'Working…' : 'Take shift'}</button></div>{!canWork && <p className="mt-2 text-[11px] text-primary">Not enough energy for this shift.</p>}{(message || error) && <p role={error ? 'alert' : 'status'} className={`mt-2 text-xs ${error ? 'text-destructive' : 'text-[#36715f]'}`}>{message || error}</p>}</article>;
}

function DashboardSkeleton() {
  return <div className="space-y-6" data-testid="status-dashboard-loading"><div className="h-16 w-2/3 animate-pulse rounded-xl bg-muted" /><div className="h-56 animate-pulse rounded-3xl bg-[#20323a]/15" /><div className="grid gap-4 sm:grid-cols-2"><div className="h-52 animate-pulse rounded-2xl bg-muted" /><div className="h-52 animate-pulse rounded-2xl bg-muted" /></div></div>;
}

function JobsPage({ player }: { player: Player }) {
  const queryClient = useQueryClient();
  const jobsQuery = useListJobs({ query: { queryKey: getListJobsQueryKey() } });
  const jobs = jobsQuery.data || [];
  const work = useWorkJobShift();
  const [feedback, setFeedback] = useState<{ jobId: string; text: string; error?: boolean } | null>(null);
  const doWork = (job: Job) => {
    setFeedback(null);
    work.mutate({ jobId: job.id }, {
      onSuccess: (result) => {
        setFeedback({ jobId: job.id, text: `Shift complete. ${cash(result.salary)} added to your cash.` });
        queryClient.invalidateQueries({ queryKey: getGetGameDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCurrentPlayerQueryKey() });
      },
      onError: (error) => setFeedback({ jobId: job.id, text: serverMessage(error, 'Shift unavailable. Try again shortly.'), error: true }),
    });
  };
  return <div className="page-enter">
    <SectionHeading eyebrow="Earn your keep" title="Work the city." detail="Every shift trades a little energy for cash, experience, and a foothold in the neighborhood." action={<div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2"><Zap size={16} className="text-[#bd8c16]" /><span className="font-mono text-xs" data-testid="text-energy-available">{player.energy} energy</span></div>} />
    <div className="mb-6 grid gap-3 sm:grid-cols-3"><MetricCard label="Current job" value={player.currentJob || 'Unemployed'} icon={BriefcaseBusiness} testId="stat-current-job" /><MetricCard label="Cash on hand" value={cash(player.cash)} icon={Wallet} tone="warm" testId="stat-job-cash" /><MetricCard label="Experience" value={player.experience.toLocaleString()} suffix={`Level ${player.level}`} icon={Sparkles} testId="stat-job-xp" /></div>
    <div className="mb-4 flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#4d8a6f]" /><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">{jobs.length} opportunities · Northside and beyond</p></div>
    {jobsQuery.isLoading ? <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{[0,1,2].map((i) => <div key={i} className="h-64 animate-pulse rounded-2xl bg-muted" />)}</div> :
      jobsQuery.error ? <QueryError message={serverMessage(jobsQuery.error, 'The job board is temporarily unavailable.')} onRetry={() => void jobsQuery.refetch()} /> :
      jobs.length === 0 ? <div className="rounded-3xl border border-dashed border-border bg-card px-6 py-14 text-center" data-testid="empty-jobs"><span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground"><BriefcaseBusiness size={21} /></span><h2 className="mt-4 font-display text-2xl font-bold uppercase">Quiet on the job front</h2><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">No shifts are listed at the moment. Give the board another look later.</p><button type="button" onClick={() => void jobsQuery.refetch()} data-testid="button-refresh-jobs" className="mt-5 rounded-xl border border-border bg-background px-4 py-2.5 text-sm font-semibold hover:bg-muted">Refresh board</button></div> :
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{jobs.map((job, index) => {
        const canWork = player.energy >= job.energyCost;
        return <article key={job.id} data-testid={`card-job-${job.id}`} className={`reveal rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-1 hover:border-primary/35 ${index > 2 ? '' : `reveal-delay-${index + 1}`}`}>
          <div className="flex items-start justify-between gap-4"><span className="grid h-11 w-11 place-items-center rounded-xl bg-secondary text-secondary-foreground"><BriefcaseBusiness size={19} /></span><span className="rounded-lg bg-[#e5eee8] px-3 py-2 font-mono text-sm font-medium text-[#37644f]">{cash(job.salary)}<small className="ml-1 text-[9px] uppercase tracking-wider">/shift</small></span></div>
          <h2 className="mt-5 font-display text-2xl font-bold uppercase leading-tight">{job.title}</h2><p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground"><MapPin size={12} />{job.district}</p>
          <p className="mt-4 min-h-[3rem] text-sm leading-6 text-muted-foreground">{job.description}</p>
          <div className="mt-5 flex items-center justify-between border-t border-border pt-4"><span className={`flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider ${canWork ? 'text-muted-foreground' : 'text-primary'}`}><Zap size={13} />{job.energyCost} energy</span><button type="button" onClick={() => doWork(job)} disabled={!canWork || work.isPending} data-testid={`button-work-${job.id}`} className="flex min-h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:bg-[#b7442d] disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground">{work.isPending ? <><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-r-transparent" />Working</> : <>Work shift <ArrowUpRight size={15} /></>}</button></div>
          {!canWork && <p className="mt-2 text-xs text-primary">Rest up first. This shift needs more energy.</p>}
          {feedback?.jobId === job.id && <p role={feedback.error ? 'alert' : 'status'} data-testid={`status-work-${job.id}`} className={`mt-3 rounded-lg px-3 py-2 text-xs leading-5 ${feedback.error ? 'bg-destructive/5 text-destructive' : 'bg-[#e5eee8] text-[#37644f]'}`}>{feedback.text}</p>}
        </article>;
      })}</div>}
    <div className="mt-8 flex items-start gap-3 rounded-2xl border border-border bg-secondary/45 p-4"><Clock3 size={17} className="mt-0.5 shrink-0 text-secondary-foreground" /><p className="text-xs leading-5 text-muted-foreground"><strong className="text-foreground">A shift is a commitment.</strong> Energy cost and earnings are set by the city. Work results update your player profile and activity log.</p></div>
  </div>;
}

function BankPage({ player }: { player: Player }) {
  const queryClient = useQueryClient();
  const transaction = useCreateBankTransaction();
  const [type, setType] = useState<'deposit' | 'withdraw'>('deposit');
  const [amount, setAmount] = useState('');
  const [feedback, setFeedback] = useState<{ message: string; error?: boolean } | null>(null);
  const available = type === 'deposit' ? player.cash : player.bankBalance;
  const parsedAmount = Number(amount);
  const valid = Number.isInteger(parsedAmount) && parsedAmount > 0 && parsedAmount <= 1000000 && parsedAmount <= available;
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!valid) return;
    setFeedback(null);
    transaction.mutate({ data: { type, amount: parsedAmount } }, {
      onSuccess: () => {
        setAmount('');
        setFeedback({ message: `${type === 'deposit' ? 'Deposit' : 'Withdrawal'} complete. Your balances are up to date.` });
        queryClient.invalidateQueries({ queryKey: getGetGameDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCurrentPlayerQueryKey() });
      },
      onError: (error) => setFeedback({ message: serverMessage(error, 'The transaction could not be completed.'), error: true }),
    });
  };
  return <div className="page-enter">
    <SectionHeading eyebrow="A little security goes a long way" title="Your money, your call." detail="Move cash between your pocket and your account. Keep a reserve for the days that do not go to plan." />
    <div className="grid gap-4 sm:grid-cols-2"><div className="relative overflow-hidden rounded-3xl bg-[#20323a] p-6 text-[#f3eee3] sm:p-8" data-testid="card-cash-balance"><div className="absolute -right-8 -top-10 h-40 w-40 rounded-full border border-white/10" /><div className="relative flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#c5ceca]">Cash on hand</p><p className="mt-4 font-display text-5xl font-bold tracking-tight sm:text-6xl" data-testid="value-cash">{cash(player.cash)}</p></div><span className="grid h-11 w-11 place-items-center rounded-xl bg-white/10"><Wallet size={20} className="text-[#e1bd5e]" /></span></div><p className="relative mt-5 text-xs text-[#c5ceca]">Ready for the street. Easy to spend, easy to lose.</p></div>
      <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-6 sm:p-8" data-testid="card-bank-balance"><div className="absolute -right-8 -top-10 h-40 w-40 rounded-full border border-border" /><div className="relative flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Bank balance</p><p className="mt-4 font-display text-5xl font-bold tracking-tight sm:text-6xl" data-testid="value-bank">{cash(player.bankBalance)}</p></div><span className="grid h-11 w-11 place-items-center rounded-xl bg-secondary text-secondary-foreground"><Landmark size={20} /></span></div><p className="relative mt-5 text-xs text-muted-foreground">Tucked away from whatever the day brings.</p></div></div>
    <section className="mt-6 grid gap-6 lg:grid-cols-[1fr_.82fr]">
      <div className="rounded-3xl border border-border bg-card p-5 sm:p-7">
        <div className="mb-6"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Secure transfer</p><h2 className="mt-1 font-display text-3xl font-bold uppercase">Move your money</h2><p className="mt-1 text-sm text-muted-foreground">Transactions are immediate and recorded to your account.</p></div>
        <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-muted p-1" role="tablist" aria-label="Transaction type">
          <button type="button" role="tab" aria-selected={type === 'deposit'} onClick={() => { setType('deposit'); setFeedback(null); }} data-testid="tab-deposit" className={`flex min-h-11 items-center justify-center gap-2 rounded-lg text-sm font-semibold transition ${type === 'deposit' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}><ArrowDownToLine size={16} />Deposit</button>
          <button type="button" role="tab" aria-selected={type === 'withdraw'} onClick={() => { setType('withdraw'); setFeedback(null); }} data-testid="tab-withdraw" className={`flex min-h-11 items-center justify-center gap-2 rounded-lg text-sm font-semibold transition ${type === 'withdraw' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}><ArrowUpRight size={16} />Withdraw</button>
        </div>
        <form onSubmit={submit}>
          <label htmlFor="bank-amount" className="mb-2 block text-sm font-semibold">Amount</label>
          <div className="relative"><span className="absolute left-4 top-1/2 -translate-y-1/2 font-mono text-muted-foreground">$</span><input id="bank-amount" type="number" min="1" max={Math.min(1000000, available)} step="1" inputMode="numeric" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0" data-testid="input-bank-amount" className="h-14 w-full rounded-xl border border-input bg-background pl-9 pr-4 font-mono text-xl outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15" /></div>
          <p className="mt-2 text-xs text-muted-foreground">Available to {type}: <strong className="font-mono text-foreground">{cash(available)}</strong><span className="ml-2">· Whole dollars only</span></p>
          {feedback && <p role={feedback.error ? 'alert' : 'status'} data-testid="status-bank-transaction" className={`mt-4 rounded-xl px-4 py-3 text-sm leading-5 ${feedback.error ? 'bg-destructive/5 text-destructive' : 'bg-[#e5eee8] text-[#37644f]'}`}>{feedback.message}</p>}
          <button type="submit" disabled={!valid || transaction.isPending} data-testid="button-bank-submit" className="mt-6 flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 font-semibold text-primary-foreground transition hover:bg-[#b7442d] disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground">{transaction.isPending ? <><span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent" />Processing…</> : <><ArrowLeftRight size={17} />{type === 'deposit' ? 'Deposit funds' : 'Withdraw funds'}</>}</button>
        </form>
      </div>
      <aside className="flex flex-col gap-4">
        <div className="rounded-3xl border border-border bg-[#e8ede7] p-5 sm:p-6"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#d2e0d5] text-[#37644f]"><HandCoins size={19} /></span><h3 className="font-display text-xl font-bold uppercase">Street-smart money</h3></div><p className="mt-4 text-sm leading-6 text-[#55645e]">A bank balance gives you a little breathing room. Keep enough cash around for daily choices, but do not carry everything you earn.</p></div>
        <div className="rounded-3xl border border-border bg-card p-5 sm:p-6"><h3 className="font-display text-xl font-bold uppercase">Your account</h3><div className="mt-4 space-y-3"><div className="flex justify-between border-b border-border pb-3 text-sm"><span className="text-muted-foreground">Player</span><strong data-testid="text-bank-player">{player.username}</strong></div><div className="flex justify-between border-b border-border pb-3 text-sm"><span className="text-muted-foreground">Current job</span><strong>{player.currentJob || 'Between jobs'}</strong></div><div className="flex justify-between text-sm"><span className="text-muted-foreground">Account status</span><span className="flex items-center gap-1.5 text-[#36715f]"><span className="h-1.5 w-1.5 rounded-full bg-[#4d8a6f]" />Active</span></div></div></div>
        <div className="rounded-2xl border border-border bg-card px-4 py-3 text-xs leading-5 text-muted-foreground"><LockKeyhole size={14} className="mr-2 inline text-primary" />Bank actions are saved to your player record. Amounts are limited to whole dollars.</div>
      </aside>
    </section>
  </div>;
}

function invalidateVehiclePurchaseQueries(queryClient: ReturnType<typeof useQueryClient>) {
  void queryClient.invalidateQueries({ queryKey: getGetCurrentPlayerQueryKey() });
  void queryClient.invalidateQueries({ queryKey: getGetGameDashboardQueryKey() });
  void queryClient.invalidateQueries({ queryKey: getListVehiclesQueryKey() });
  void queryClient.invalidateQueries({ queryKey: getGetGarageQueryKey() });
}

function DealershipPage({ player }: { player: Player }) {
  const queryClient = useQueryClient();
  const catalogQuery = useListVehicles({
    query: { enabled: !!player.id, queryKey: getListVehiclesQueryKey() },
  });
  const purchase = usePurchaseVehicle();
  const pendingVehicle = useRef<string | null>(null);
  const idempotencyKeys = useRef(new Map<string, string>());
  const [feedback, setFeedback] = useState<{ vehicleId: string; message: string; error?: boolean } | null>(null);
  const buy = (vehicle: DealershipVehicle) => {
    if (vehicle.owned || purchase.isPending) return;
    const storageKey = `rlo:vehicle-purchase:${player.id}:${vehicle.id}`;
    let idempotencyKey = idempotencyKeys.current.get(storageKey) || null;
    try { idempotencyKey ||= sessionStorage.getItem(storageKey); } catch { /* Keep the retry key in memory when browser storage is unavailable. */ }
    if (!idempotencyKey) {
      idempotencyKey = crypto.randomUUID();
      idempotencyKeys.current.set(storageKey, idempotencyKey);
      try { sessionStorage.setItem(storageKey, idempotencyKey); } catch { /* The in-memory key remains stable for retries. */ }
    }
    idempotencyKeys.current.set(storageKey, idempotencyKey);
    pendingVehicle.current = vehicle.id;
    setFeedback(null);
    purchase.mutate({ data: { vehicleId: vehicle.id, idempotencyKey } }, {
      onSuccess: (result) => {
        idempotencyKeys.current.delete(storageKey);
        try { sessionStorage.removeItem(storageKey); } catch { /* Storage is optional; the purchase is already confirmed. */ }
        pendingVehicle.current = null;
        setFeedback({ vehicleId: vehicle.id, message: result.replayed ? `${vehicle.name} purchase confirmed. Your earlier request was safely replayed.` : `${vehicle.name} is yours. The city is waiting.` });
        invalidateVehiclePurchaseQueries(queryClient);
      },
      onError: (error) => {
        pendingVehicle.current = null;
        setFeedback({ vehicleId: vehicle.id, message: serverMessage(error, 'Purchase could not be completed. Retry to safely check the same purchase request.'), error: true });
      },
    });
  };
  const vehicles = catalogQuery.data || [];
  return <div className="page-enter" data-testid="page-dealership">
    <SectionHeading eyebrow="Northside Motors · Keys to the city" title="Vehicle Dealership" detail="Pick a machine that matches the life you are building. Purchases are paid from your cash on hand." action={<div className="rounded-xl border border-border bg-card px-4 py-2.5"><span className="block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Cash on hand</span><strong className="font-mono text-sm" data-testid="text-dealership-cash">{cash(player.cash)}</strong></div>} />
    <div className="mb-6 flex items-center justify-between gap-3 rounded-2xl border border-border bg-card px-4 py-3"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground"><KeyRound size={18} /></span><div><p className="text-sm font-semibold">Choose once. Keep it.</p><p className="text-xs text-muted-foreground">Owned models stay in your garage.</p></div></div><Link href="/garage" data-testid="link-dealership-garage" className="flex min-h-10 items-center gap-1 rounded-lg border border-border px-3 text-xs font-semibold hover:bg-muted">My Garage <ChevronRight size={14} /></Link></div>
    {catalogQuery.isLoading ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" data-testid="status-dealership-loading">{[0,1,2,3,4,5].map((n) => <div key={n} className="h-64 animate-pulse rounded-2xl border border-border bg-card" />)}</div> :
      catalogQuery.error ? <QueryError message={serverMessage(catalogQuery.error, 'The dealership is unavailable right now.')} onRetry={() => void catalogQuery.refetch()} /> :
      vehicles.length === 0 ? <div className="rounded-3xl border border-dashed border-border bg-card px-6 py-14 text-center" data-testid="empty-dealership"><CarFront size={26} className="mx-auto text-primary" /><h2 className="mt-4 font-display text-2xl font-bold uppercase">No inventory today</h2><p className="mt-2 text-sm text-muted-foreground">Check back soon for new arrivals.</p><button type="button" onClick={() => void catalogQuery.refetch()} data-testid="button-refresh-dealership" className="mt-5 min-h-11 rounded-xl border border-border bg-background px-4 text-sm font-semibold">Refresh inventory</button></div> :
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{vehicles.map((vehicle, index) => {
        const pending = purchase.isPending && pendingVehicle.current === vehicle.id;
        const feedbackHere = feedback?.vehicleId === vehicle.id ? feedback : null;
        return <article key={vehicle.id} data-testid={`card-vehicle-${vehicle.id}`} className={`reveal flex min-h-[290px] flex-col rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-0.5 hover:border-primary/35 ${index < 3 ? `reveal-delay-${index + 1}` : ''}`}>
          <div className="flex items-start justify-between gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground"><CarFront size={23} /></span><span className="rounded-lg border border-border px-2.5 py-1 font-mono text-[9px] uppercase tracking-widest text-muted-foreground" data-testid={`text-vehicle-category-${vehicle.id}`}>{vehicle.category}</span></div>
          <h2 className="mt-5 font-display text-3xl font-bold uppercase leading-none" data-testid={`text-vehicle-name-${vehicle.id}`}>{vehicle.name}</h2>
          <p className="mt-3 min-h-12 text-sm leading-6 text-muted-foreground" data-testid={`text-vehicle-description-${vehicle.id}`}>{vehicle.description}</p>
          <div className="mt-auto">
            <div className="mb-4 flex items-end justify-between border-t border-border pt-4"><span className="font-mono text-[9px] uppercase tracking-[.16em] text-muted-foreground">Asking price</span><strong className="font-display text-2xl font-bold" data-testid={`text-vehicle-price-${vehicle.id}`}>{cash(vehicle.price)}</strong></div>
            {vehicle.owned ?
              <div data-testid={`status-vehicle-owned-${vehicle.id}`} className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-secondary/70 text-sm font-semibold text-secondary-foreground"><Check size={17} /> In your collection</div> :
               <><div data-testid={`status-vehicle-unowned-${vehicle.id}`} className="mb-2 flex min-h-8 items-center justify-center rounded-lg bg-muted/70 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Not owned</div><button type="button" onClick={() => buy(vehicle)} disabled={purchase.isPending} data-testid={`button-buy-${vehicle.id}`} className="flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:bg-[#b7442d] disabled:cursor-wait disabled:opacity-60">{pending ? <><span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent" />Processing purchase…</> : <>Purchase vehicle <ArrowUpRight size={16} /></>}</button></>}
            {feedbackHere && <p role={feedbackHere.error ? 'alert' : 'status'} data-testid={`status-purchase-${vehicle.id}`} className={`mt-3 rounded-xl px-3 py-2.5 text-xs leading-5 ${feedbackHere.error ? 'bg-destructive/10 text-destructive' : 'bg-secondary text-secondary-foreground'}`}>{feedbackHere.message}{feedbackHere.error && !purchase.isPending && <button type="button" onClick={() => buy(vehicle)} data-testid={`button-retry-purchase-${vehicle.id}`} className="ml-1 font-bold underline underline-offset-2">Retry safely</button>}</p>}
          </div>
        </article>;
      })}</div>}
    <p className="mt-6 text-center font-mono text-[9px] uppercase tracking-[.17em] text-muted-foreground">Prices are settled by the dealership · purchases use cash on hand</p>
  </div>;
}

function GaragePage({ player }: { player: Player }) {
  const queryClient = useQueryClient();
  const garageQuery = useGetGarage({ query: { enabled: !!player.id, queryKey: getGetGarageQueryKey() } });
  const setActive = useSetActiveVehicle();
  const [feedback, setFeedback] = useState<{ vehicleId: number; message: string; error?: boolean } | null>(null);
  const activate = (vehicle: PlayerVehicle) => {
    if (vehicle.ownershipStatus !== 'owned' || vehicle.isActive || setActive.isPending) return;
    setFeedback(null);
    setActive.mutate({ data: { vehicleRecordId: vehicle.id } }, {
      onSuccess: () => {
        setFeedback({ vehicleId: vehicle.id, message: `${vehicle.name} is now your active vehicle.` });
        void queryClient.invalidateQueries({ queryKey: getGetGarageQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetGameDashboardQueryKey() });
      },
      onError: (error) => setFeedback({ vehicleId: vehicle.id, message: serverMessage(error, 'Could not switch vehicles. Please try again.'), error: true }),
    });
  };
  const vehicles = garageQuery.data?.vehicles || [];
  return <div className="page-enter" data-testid="page-garage">
    <SectionHeading eyebrow="Your private parking" title="My Garage" detail="Your owned vehicles, purchase records, and the ride you have chosen for the road." action={<Link href="/dealership" data-testid="link-garage-dealership" className="flex min-h-11 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground"><CarFront size={17} /> Visit dealership</Link>} />
    {garageQuery.isLoading ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" data-testid="status-garage-loading">{[0,1,2].map((n) => <div key={n} className="h-64 animate-pulse rounded-2xl bg-muted" />)}</div> :
      garageQuery.error ? <QueryError message={serverMessage(garageQuery.error, 'Your garage could not load right now.')} onRetry={() => void garageQuery.refetch()} /> :
      vehicles.length === 0 ? <div className="rounded-3xl border border-dashed border-border bg-card px-6 py-14 text-center" data-testid="empty-garage"><span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-secondary-foreground"><KeyRound size={23} /></span><p className="mt-5 font-mono text-[10px] uppercase tracking-[.19em] text-primary">The first parking spot is waiting</p><h2 className="mt-2 font-display text-3xl font-bold uppercase">A city, on your terms.</h2><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">You have not picked up a vehicle yet. Find something that fits your next move.</p><Link href="/dealership" data-testid="link-empty-garage-dealership" className="mx-auto mt-6 flex min-h-12 w-fit items-center gap-2 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground">Browse vehicles <ChevronRight size={16} /></Link></div> :
      <><div className="mb-5 flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3"><p className="font-mono text-[10px] uppercase tracking-[.15em] text-muted-foreground">{vehicles.length} {vehicles.length === 1 ? 'vehicle' : 'vehicles'} in your collection</p><span className="flex items-center gap-2 text-xs text-muted-foreground"><span className="h-2 w-2 rounded-full bg-[#d2aa4c]" />Active ride is ready</span></div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{vehicles.map((vehicle, index) => { const isActive = vehicle.isActive || vehicle.id === garageQuery.data?.activeVehicleId; return <article key={vehicle.id} data-testid={`card-garage-vehicle-${vehicle.id}`} className={`reveal flex min-h-[295px] flex-col rounded-2xl border ${isActive ? 'border-primary/40 bg-card shadow-[0_14px_40px_-28px_rgba(210,170,76,.6)]' : 'border-border bg-card'} p-5 ${index < 3 ? `reveal-delay-${index + 1}` : ''}`}>
        <div className="flex items-start justify-between"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground"><CarFront size={23} /></span><span data-testid={`status-garage-vehicle-${vehicle.id}`} className={`rounded-full px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider ${isActive ? 'bg-primary/15 text-primary' : 'bg-muted text-muted-foreground'}`}>{isActive ? 'Active vehicle' : vehicle.ownershipStatus === 'owned' ? 'Owned' : vehicle.ownershipStatus}</span></div>
        <h2 className="mt-5 font-display text-3xl font-bold uppercase leading-none" data-testid={`text-garage-vehicle-name-${vehicle.id}`}>{vehicle.name}</h2><p className="mt-1 text-xs text-muted-foreground">{vehicle.category}</p>
        <div className="mt-5 space-y-3 border-t border-border pt-4"><div className="flex items-center justify-between gap-3 text-xs"><span className="flex items-center gap-2 text-muted-foreground"><CalendarDays size={14} /> Purchased</span><time dateTime={vehicle.purchasedAt} data-testid={`text-purchased-at-${vehicle.id}`} className="font-medium">{new Date(vehicle.purchasedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</time></div><div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">Purchase price</span><strong className="font-mono" data-testid={`text-purchase-price-${vehicle.id}`}>{cash(vehicle.purchasePrice)}</strong></div></div>
        <div className="mt-auto pt-5">{isActive ? <div className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary/10 text-sm font-semibold text-primary"><Check size={16} /> Currently active</div> : <button type="button" disabled={vehicle.ownershipStatus !== 'owned' || setActive.isPending} onClick={() => activate(vehicle)} data-testid={`button-activate-vehicle-${vehicle.id}`} className="flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 text-sm font-semibold transition hover:border-primary/40 hover:bg-muted disabled:cursor-not-allowed disabled:opacity-55">{setActive.isPending ? 'Switching vehicle…' : 'Make active vehicle'} <ArrowUpRight size={15} /></button>}
        {feedback?.vehicleId === vehicle.id && <p role={feedback.error ? 'alert' : 'status'} data-testid={`status-activate-vehicle-${vehicle.id}`} className={`mt-3 rounded-lg px-3 py-2 text-xs leading-5 ${feedback.error ? 'bg-destructive/10 text-destructive' : 'bg-secondary text-secondary-foreground'}`}>{feedback.message}</p>}</div>
      </article>; })}</div></>}
  </div>;
}

type PhoneApp = { id: string; label: string; icon: typeof Smartphone; description: string };
const phoneApps: PhoneApp[] = [
  { id: 'profile', label: 'Profile', icon: UserRound, description: 'Your player standing and condition.' },
  { id: 'banking', label: 'Banking', icon: Landmark, description: 'Move money between cash and the bank.' },
  { id: 'jobs', label: 'Jobs', icon: BriefcaseBusiness, description: 'Find work and take a shift.' },
  { id: 'vehicles', label: 'Vehicles', icon: CarFront, description: 'Your garage and the dealership.' },
  { id: 'properties', label: 'Properties', icon: House, description: 'Property features are not available yet.' },
  { id: 'shopping', label: 'Shopping', icon: ShoppingBag, description: 'Shopping features are not available yet.' },
  { id: 'lifestyle', label: 'Lifestyle', icon: Heart, description: 'Lifestyle features are not available yet.' },
  { id: 'cryptocurrency', label: 'Cryptocurrency', icon: Bitcoin, description: 'Cryptocurrency features are not available yet.' },
  { id: 'contacts', label: 'Contacts', icon: Contact, description: 'Contacts are not available yet.' },
  { id: 'messages', label: 'Messages', icon: MessagesSquare, description: 'Messaging is not available yet.' },
  { id: 'city-map', label: 'City Map', icon: Map, description: 'The city map is not available yet.' },
  { id: 'government', label: 'Government', icon: Building2, description: 'Government features are not available yet.' },
  { id: 'sfcc', label: 'SFCC', icon: Store, description: 'SFCC features are not available yet.' },
  { id: 'settings', label: 'Settings', icon: Settings, description: 'Personalize how the game moves.' },
];

function PhonePage({ player, appId }: { player: Player; appId?: string }) {
  const [, navigate] = useLocation();
  const app = phoneApps.find((item) => item.id === appId);
  const dashboard = useGetGameDashboard({ query: { enabled: !!player.id, queryKey: getGetGameDashboardQueryKey() } });
  const goHome = () => navigate('/phone');
  const closePhone = () => navigate('/dashboard');
  const home = !appId;
  const isLiveFeature = appId === 'banking' || appId === 'jobs';

  return <div className="page-enter phone-experience" data-testid="page-phone">
    <div className="phone-topline"><div><p className="font-mono text-[10px] uppercase tracking-[.22em] text-primary">Personal device · City network</p><h1 className="mt-1 font-display text-4xl font-bold uppercase leading-none sm:text-5xl">{home ? 'Your phone' : app?.label || 'City app'}</h1></div><button type="button" onClick={closePhone} data-testid="button-phone-minimize" aria-label="Close phone and return to dashboard" className="flex min-h-11 items-center gap-2 rounded-xl border border-border bg-card px-4 text-sm font-semibold transition hover:border-primary/50 hover:text-primary"><Minimize2 size={16} /><span className="hidden sm:inline">Dashboard</span></button></div>
    <div className="phone-workspace">
      <section className={`phone-device ${!home ? 'phone-device-app' : ''}`} aria-label="Player phone">
        <div className="phone-bezel">
          <div className="phone-screen">
            <div className="phone-statusbar"><span className="font-mono text-[10px] font-medium tracking-wider">RLO</span><div className="flex items-center gap-2 text-primary"><Wifi size={14} /><BatteryFull size={16} /></div></div>
            {home ? <>
              <div className="phone-welcome"><p className="font-mono text-[9px] uppercase tracking-[.22em] text-primary">San Fierro · Player device</p><h2 className="mt-1 font-display text-3xl font-bold uppercase leading-none" data-testid="text-phone-owner">{player.username}</h2><p className="mt-1 text-xs text-muted-foreground">Level {player.level} <span className="px-1.5 text-primary">/</span>{player.currentJob || 'Between jobs'}</p></div>
              <div className="phone-balance-strip"><div><span>Cash</span><strong data-testid="text-phone-cash">{cash(player.cash)}</strong></div><div><span>Bank</span><strong data-testid="text-phone-bank">{cash(player.bankBalance)}</strong></div></div>
              <div className="phone-app-grid" aria-label="Phone apps">
                {phoneApps.map((item) => { const Icon = item.icon; return <Link href={`/phone/${item.id}`} key={item.id} data-testid={`link-phone-app-${item.id}`} aria-label={`Open ${item.label}`} className="phone-app-icon"><span className="phone-app-tile"><Icon size={21} strokeWidth={1.7} /></span><span>{item.label}</span></Link>; })}
              </div>
              <div className="phone-dock" aria-label="Quick access"><Link href="/phone/banking" data-testid="link-phone-dock-banking" aria-label="Open banking"><Landmark size={19} /></Link><Link href="/phone/jobs" data-testid="link-phone-dock-jobs" aria-label="Open jobs"><BriefcaseBusiness size={19} /></Link><Link href="/phone/vehicles" data-testid="link-phone-dock-vehicles" aria-label="Open vehicles"><CarFront size={19} /></Link></div>
            </> : <>
              <div className="phone-appbar"><button type="button" onClick={goHome} data-testid="button-phone-back-home" aria-label="Back to phone home" className="grid h-10 w-10 place-items-center rounded-xl border border-border bg-background text-foreground"><ChevronLeft size={19} /></button><div className="min-w-0 flex-1"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-primary">RLO application</p><h2 className="truncate font-display text-2xl font-bold uppercase leading-none">{app?.label || 'City app'}</h2></div><button type="button" onClick={closePhone} data-testid="button-phone-close-app" aria-label="Minimize phone to dashboard" className="grid h-10 w-10 place-items-center rounded-xl border border-border bg-background text-muted-foreground"><Minimize2 size={16} /></button></div>
              <div className="phone-app-content">
                {appId === 'profile' && <PhoneProfile player={player} dashboard={dashboard} />}
                {appId === 'banking' && <><div className="phone-feature-intro"><p>Banking is handled by your city bank account.</p></div><BankPage player={player} /><PhoneBankActivity dashboard={dashboard} /></>}
                {appId === 'jobs' && <><div className="phone-feature-intro"><p>Available work and shifts.</p></div><JobsPage player={player} /></>}
                {appId === 'vehicles' && <PhoneVehicles player={player} />}
                {appId === 'settings' && <PhoneSettings />}
                {app && !isLiveFeature && appId !== 'profile' && appId !== 'vehicles' && appId !== 'settings' && <ComingSoonApp app={app} />}
                {!app && <ComingSoonApp app={{ id: appId || 'unknown', label: 'City app', icon: CircleHelp, description: 'This city app is not available yet.' }} />}
              </div>
            </>}
            <div className="phone-home-indicator" aria-hidden="true"><span /></div>
          </div>
        </div>
      </section>
      <aside className="phone-side-panel">
        <div className="phone-side-copy"><span className="font-mono text-[10px] uppercase tracking-[.2em] text-primary">Your line to the city</span><h2 className="mt-3 font-display text-4xl font-bold uppercase leading-[.93]">Everything you need.<br /><span className="text-primary">In your pocket.</span></h2><p className="mt-4 max-w-sm text-sm leading-6 text-muted-foreground">Open the apps tied to your life here. Work, banking, and vehicles connect to the same systems as the rest of the city.</p></div>
        <div className="phone-side-player"><div className="grid h-11 w-11 place-items-center rounded-xl border border-primary/30 bg-primary/10 font-display text-xl font-bold text-primary">{player.username.slice(0, 1).toUpperCase()}</div><div><p className="text-sm font-semibold">{player.username}</p><p className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">Level {player.level} · Single player</p></div><Link href="/dashboard" data-testid="link-phone-side-dashboard" className="ml-auto grid h-10 w-10 place-items-center rounded-lg text-muted-foreground transition hover:bg-muted hover:text-primary" aria-label="Return to dashboard"><ArrowUpRight size={17} /></Link></div>
      </aside>
    </div>
  </div>;
}

function PhoneProfile({ player, dashboard }: { player: Player; dashboard: ReturnType<typeof useGetGameDashboard> }) {
  return <div className="space-y-4" data-testid="phone-profile-content">
    <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-primary">Character profile</p><h3 className="mt-1 font-display text-3xl font-bold uppercase">{player.username}</h3><p className="mt-1 text-xs text-muted-foreground">Level {player.level} · {player.currentJob || 'Between jobs'}</p></div>
    {dashboard.isLoading ? <div className="space-y-2" data-testid="status-phone-profile-loading"><div className="h-16 animate-pulse rounded-xl bg-muted" /><div className="h-16 animate-pulse rounded-xl bg-muted" /></div> : dashboard.error ? <QueryError message={serverMessage(dashboard.error, 'Profile details could not load.')} onRetry={() => void dashboard.refetch()} /> : <div className="grid grid-cols-2 gap-2">{[
      { label: 'Health', value: `${player.health}%`, icon: HeartPulse },
      { label: 'Energy', value: `${player.energy}%`, icon: Zap },
      { label: 'Experience', value: player.experience.toLocaleString(), icon: Sparkles },
      { label: 'Reputation', value: String(player.reputation), icon: ActivityIcon },
      { label: 'Wanted level', value: `${player.wantedLevel} / 5`, icon: ShieldAlert },
      { label: 'Cash', value: cash(player.cash), icon: Wallet },
    ].map(({ label, value, icon: Icon }) => <div key={label} className="rounded-xl border border-border bg-background p-3" data-testid={`phone-profile-stat-${label.toLowerCase().replaceAll(' ', '-')}`}><div className="flex items-center gap-2 text-[9px] uppercase tracking-wider text-muted-foreground"><Icon size={13} className="text-primary" />{label}</div><strong className="mt-3 block break-words font-display text-2xl leading-none">{value}</strong></div>)}</div>}
  </div>;
}

function PhoneBankActivity({ dashboard }: { dashboard: ReturnType<typeof useGetGameDashboard> }) {
  if (dashboard.isLoading) return <div className="mt-4 h-24 animate-pulse rounded-xl bg-muted" data-testid="status-phone-bank-loading" />;
  if (dashboard.error) return <div className="mt-4 rounded-xl border border-border bg-background p-3 text-xs text-muted-foreground" data-testid="status-phone-bank-activity-error">Recent activity is unavailable right now.</div>;
  const bankEvents = (dashboard.data?.activities || []).filter((event) => event.kind === 'deposit' || event.kind === 'withdraw').slice(0, 4);
  return <section className="mt-4 rounded-2xl border border-border bg-background p-4" aria-label="Recent bank activity" data-testid="section-phone-bank-activity"><p className="font-mono text-[9px] uppercase tracking-[.15em] text-primary">Recent bank activity</p><p className="mb-2 mt-1 text-[10px] leading-4 text-muted-foreground">Recent events only, not a full transaction ledger.</p>{bankEvents.length === 0 ? <p className="py-2 text-xs text-muted-foreground" data-testid="empty-phone-bank-activity">No recent bank activity.</p> : bankEvents.map((event) => <div key={event.id} data-testid={`row-phone-bank-activity-${event.id}`} className="flex items-center justify-between gap-3 border-t border-border py-2 first:border-0"><div className="min-w-0"><p className="truncate text-xs font-medium">{event.description}</p><p className="font-mono text-[9px] text-muted-foreground">{timeAgo(event.createdAt)}</p></div>{event.amount !== null && <strong className="shrink-0 font-mono text-[10px] text-primary">{event.amount >= 0 ? '+' : '−'}{cash(Math.abs(event.amount))}</strong>}</div>)}</section>;
}

function PhoneVehicles({ player }: { player: Player }) {
  const vehicles = useListVehicles({ query: { enabled: !!player.id, queryKey: getListVehiclesQueryKey() } });
  const garage = useGetGarage({ query: { enabled: !!player.id, queryKey: getGetGarageQueryKey() } });
  return <div className="space-y-4" data-testid="phone-vehicles-content">
    <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-primary">Your vehicles</p><h3 className="mt-1 font-display text-3xl font-bold uppercase">Keys & wheels</h3><p className="mt-1 text-xs leading-5 text-muted-foreground">See what you own, then open the full garage or dealership.</p></div>
    {garage.isLoading ? <div className="space-y-2" data-testid="status-phone-garage-loading"><div className="h-20 animate-pulse rounded-xl bg-muted" /><div className="h-20 animate-pulse rounded-xl bg-muted" /></div> : garage.error ? <QueryError message={serverMessage(garage.error, 'Your garage could not load.')} onRetry={() => void garage.refetch()} /> : (garage.data?.vehicles || []).length === 0 ? <div className="rounded-xl border border-dashed border-border p-4 text-xs leading-5 text-muted-foreground" data-testid="empty-phone-owned-vehicles">No vehicles in your garage yet. The dealership is open when you are ready.</div> : <section className="space-y-2" aria-label="Owned vehicles"><p className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">In your garage</p>{garage.data?.vehicles.map((vehicle) => <div key={vehicle.id} className="flex items-center gap-3 rounded-xl border border-border bg-background p-3" data-testid={`phone-owned-vehicle-${vehicle.id}`}><span className="grid h-10 w-10 place-items-center rounded-lg bg-secondary text-secondary-foreground"><CarFront size={18} /></span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{vehicle.name}</p><p className="text-[10px] text-muted-foreground">{vehicle.category}</p></div>{vehicle.isActive && <span className="rounded-full bg-primary/10 px-2 py-1 font-mono text-[8px] uppercase text-primary">Active</span>}</div>)}</section>}
    {vehicles.isLoading ? <div className="h-14 animate-pulse rounded-xl bg-muted" data-testid="status-phone-dealership-loading" /> : vehicles.error ? <div className="rounded-xl border border-border p-3 text-xs text-muted-foreground" data-testid="status-phone-dealership-error">Dealership inventory is unavailable. Try again from the dealership.</div> : <p className="text-xs text-muted-foreground" data-testid="text-phone-inventory-count">{vehicles.data?.length || 0} vehicles listed at the dealership.</p>}
    <div className="grid grid-cols-2 gap-2"><Link href="/garage" data-testid="link-phone-garage" className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-border bg-background px-3 text-xs font-semibold hover:border-primary/40"><Gauge size={15} />My garage</Link><Link href="/dealership" data-testid="link-phone-dealership" className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-primary px-3 text-xs font-semibold text-primary-foreground hover:brightness-110"><CarFront size={15} />Dealership</Link></div>
  </div>;
}

function PhoneSettings() {
  const [reduced, setReduced] = useState(() => {
    try { return localStorage.getItem('rlo-reduced-motion') === 'true'; } catch { return false; }
  });
  useEffect(() => {
    document.documentElement.toggleAttribute('data-reduced-motion', reduced);
    try { localStorage.setItem('rlo-reduced-motion', String(reduced)); } catch { /* Storage may be disabled. */ }
    return () => document.documentElement.removeAttribute('data-reduced-motion');
  }, [reduced]);
  return <div className="space-y-4" data-testid="phone-settings-content"><div className="rounded-2xl border border-primary/20 bg-primary/5 p-4"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-primary">Device preferences</p><h3 className="mt-1 font-display text-3xl font-bold uppercase">Settings</h3></div><label className="flex min-h-[68px] cursor-pointer items-center justify-between gap-4 rounded-xl border border-border bg-background p-4" data-testid="setting-reduced-motion"><span><strong className="block text-sm">Reduced motion</strong><span className="mt-1 block text-[10px] leading-4 text-muted-foreground">Reduce interface movement on this device.</span></span><input type="checkbox" checked={reduced} onChange={(event) => setReduced(event.target.checked)} data-testid="input-reduced-motion" aria-label="Enable reduced motion" className="h-5 w-5 accent-[hsl(var(--primary))]" /></label><p className="text-[10px] leading-4 text-muted-foreground">This preference is stored on this device. Account and sign-in details are not stored here.</p></div>;
}

function ComingSoonApp({ app }: { app: PhoneApp }) {
  const Icon = app.icon;
  return <div className="flex min-h-[310px] flex-col items-center justify-center rounded-2xl border border-dashed border-primary/30 bg-primary/[.035] px-5 py-8 text-center" data-testid={`phone-coming-soon-${app.id}`}><span className="grid h-14 w-14 place-items-center rounded-2xl border border-primary/25 bg-primary/10 text-primary"><Icon size={25} /></span><p className="mt-5 font-mono text-[9px] uppercase tracking-[.2em] text-primary">Coming soon</p><h3 className="mt-1 font-display text-3xl font-bold uppercase">{app.label}</h3><p className="mt-2 max-w-[260px] text-xs leading-5 text-muted-foreground">{app.description}</p></div>;
}

function ProtectedRoute({ children }: { children: (player: Player) => ReactNode }) {
  const [, navigate] = useLocation();
  const { data: player, isLoading } = useGetCurrentPlayer({
    query: { queryKey: getGetCurrentPlayerQueryKey(), retry: false },
  });
  useEffect(() => { if (!isLoading && !player) navigate('/'); }, [isLoading, player, navigate]);
  if (isLoading || !player) return <LoadingScreen />;
  return <AppShell player={player}>{children(player)}</AppShell>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch>
    <Route path="/" component={AuthPage} />
    <Route path="/dashboard">{() => <ProtectedRoute>{(player) => <DashboardPage player={player} />}</ProtectedRoute>}</Route>
    <Route path="/jobs">{() => <ProtectedRoute>{(player) => <JobsPage player={player} />}</ProtectedRoute>}</Route>
    <Route path="/bank">{() => <ProtectedRoute>{(player) => <BankPage player={player} />}</ProtectedRoute>}</Route>
    <Route path="/dealership">{() => <ProtectedRoute>{(player) => <DealershipPage player={player} />}</ProtectedRoute>}</Route>
    <Route path="/garage">{() => <ProtectedRoute>{(player) => <GaragePage player={player} />}</ProtectedRoute>}</Route>
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
