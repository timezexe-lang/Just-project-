import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import session from "express-session";

const databasePath = path.resolve(
  process.env.SQLITE_PATH ??
    path.join(process.cwd(), "data", "real-life-online.sqlite"),
);
mkdirSync(path.dirname(databasePath), { recursive: true });

export const db = new DatabaseSync(databasePath);
db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;");
db.exec(`
  CREATE TABLE IF NOT EXISTS players (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    cash INTEGER NOT NULL DEFAULT 10000 CHECK(cash >= 0),
    bank_balance INTEGER NOT NULL DEFAULT 20000 CHECK(bank_balance >= 0),
    level INTEGER NOT NULL DEFAULT 1 CHECK(level >= 1),
    experience INTEGER NOT NULL DEFAULT 0 CHECK(experience >= 0),
    health INTEGER NOT NULL DEFAULT 100 CHECK(health BETWEEN 0 AND 100),
    energy INTEGER NOT NULL DEFAULT 100 CHECK(energy BETWEEN 0 AND 100),
    reputation INTEGER NOT NULL DEFAULT 0,
    wanted_level INTEGER NOT NULL DEFAULT 0 CHECK(wanted_level BETWEEN 0 AND 5),
    current_job TEXT,
    last_work_at INTEGER,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    district TEXT NOT NULL,
    salary INTEGER NOT NULL CHECK(salary > 0),
    energy_cost INTEGER NOT NULL CHECK(energy_cost >= 0),
    description TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    description TEXT NOT NULL,
    amount INTEGER,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS activities_player_created_idx
    ON activities(player_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS vehicle_catalog (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price INTEGER NOT NULL CHECK(price > 0)
  );

  CREATE TABLE IF NOT EXISTS player_vehicles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
    vehicle_id TEXT NOT NULL REFERENCES vehicle_catalog(id) ON DELETE RESTRICT,
    purchase_price INTEGER NOT NULL CHECK(purchase_price > 0),
    ownership_status TEXT NOT NULL DEFAULT 'owned' CHECK(ownership_status = 'owned'),
    purchased_at TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 0 CHECK(is_active IN (0, 1)),
    purchase_request_id TEXT NOT NULL,
    UNIQUE(player_id, purchase_request_id)
  );
  CREATE INDEX IF NOT EXISTS player_vehicles_owner_idx
    ON player_vehicles(player_id, id);
  CREATE UNIQUE INDEX IF NOT EXISTS player_vehicles_one_model_per_player_idx
    ON player_vehicles(player_id, vehicle_id);
  CREATE UNIQUE INDEX IF NOT EXISTS player_vehicles_one_active_idx
    ON player_vehicles(player_id) WHERE is_active = 1;

  CREATE TABLE IF NOT EXISTS sessions (
    sid TEXT PRIMARY KEY,
    sess TEXT NOT NULL,
    expires_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
`);

const vehicleCatalogColumns = db
  .prepare("PRAGMA table_info(vehicle_catalog)")
  .all() as { name: string }[];
if (!vehicleCatalogColumns.some((column) => column.name === "description")) {
  db.exec(
    "ALTER TABLE vehicle_catalog ADD COLUMN description TEXT NOT NULL DEFAULT ''",
  );
}

const seedVehicle = db.prepare(`
  INSERT INTO vehicle_catalog (id, name, category, description, price)
  VALUES (?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET
    name = excluded.name,
    category = excluded.category,
    description = excluded.description,
    price = excluded.price
`);
seedVehicle.run(
  "faggio-scooter",
  "Faggio",
  "Scooter",
  "A nimble scooter for quick trips across town.",
  5000,
);
seedVehicle.run(
  "premier-sedan",
  "Premier",
  "Sedan",
  "A practical four-door built for everyday city driving.",
  25000,
);
seedVehicle.run(
  "huntley-suv",
  "Huntley",
  "SUV",
  "A roomy utility vehicle ready for long days on the road.",
  90000,
);
seedVehicle.run(
  "infernus-sports-car",
  "Infernus",
  "Sports Car",
  "A striking performance coupe with an unmistakable profile.",
  150000,
);
seedVehicle.run(
  "bullet-supercar",
  "Bullet",
  "Supercar",
  "A low-slung supercar built for dramatic city arrivals.",
  250000,
);
seedVehicle.run(
  "turismo-luxury-supercar",
  "Turismo",
  "Luxury Supercar",
  "A refined grand tourer for the city's most exclusive streets.",
  350000,
);

const seedJob = db.prepare(`
  INSERT OR IGNORE INTO jobs (id, title, district, salary, energy_cost, description)
  VALUES (?, ?, ?, ?, ?, ?)
`);
seedJob.run(
  "market-assistant",
  "Market Assistant",
  "Old Town",
  550,
  7,
  "Help local vendors keep the market moving during a busy shift.",
);
seedJob.run(
  "dock-runner",
  "Dock Runner",
  "Harbor District",
  800,
  10,
  "Move scheduled freight between the docks and nearby warehouses.",
);
seedJob.run(
  "night-courier",
  "Night Courier",
  "Central Ward",
  1050,
  14,
  "Deliver time-sensitive parcels across the city after dark.",
);

db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(Date.now());

type SessionRecord = {
  sid: string;
  sess: string;
  expires_at: number;
};

export class SQLiteSessionStore extends session.Store {
  constructor() {
    super();
  }

  private readonly getStatement = db.prepare(
    "SELECT sid, sess, expires_at FROM sessions WHERE sid = ?",
  );
  private readonly setStatement = db.prepare(`
    INSERT INTO sessions (sid, sess, expires_at) VALUES (?, ?, ?)
    ON CONFLICT(sid) DO UPDATE SET sess = excluded.sess, expires_at = excluded.expires_at
  `);
  private readonly destroyStatement = db.prepare(
    "DELETE FROM sessions WHERE sid = ?",
  );
  private readonly touchStatement = db.prepare(
    "UPDATE sessions SET expires_at = ? WHERE sid = ?",
  );
  private readonly deleteExpiredStatement = db.prepare(
    "DELETE FROM sessions WHERE expires_at <= ?",
  );

  get(
    sid: string,
    callback: (err: Error | null, session?: session.SessionData | null) => void,
  ): void {
    try {
      const row = this.getStatement.get(sid) as SessionRecord | undefined;
      if (!row) {
        callback(null, null);
        return;
      }
      if (row.expires_at <= Date.now()) {
        this.destroyStatement.run(sid);
        callback(null, null);
        return;
      }
      callback(null, JSON.parse(row.sess) as session.SessionData);
    } catch (error) {
      callback(error instanceof Error ? error : new Error("Session lookup failed."));
    }
  }

  set(
    sid: string,
    sessionData: session.SessionData,
    callback?: (err?: Error | null) => void,
  ): void {
    try {
      const expiry = sessionData.cookie.expires
        ? new Date(sessionData.cookie.expires).getTime()
        : Date.now() + (sessionData.cookie.maxAge ?? 7 * 24 * 60 * 60 * 1000);
      this.setStatement.run(sid, JSON.stringify(sessionData), expiry);
      this.deleteExpiredStatement.run(Date.now());
      callback?.(null);
    } catch (error) {
      callback?.(error instanceof Error ? error : new Error("Session save failed."));
    }
  }

  destroy(sid: string, callback?: (err?: Error | null) => void): void {
    try {
      this.destroyStatement.run(sid);
      callback?.(null);
    } catch (error) {
      callback?.(
        error instanceof Error ? error : new Error("Session removal failed."),
      );
    }
  }

  touch(
    sid: string,
    sessionData: session.SessionData,
    callback?: (err?: Error | null) => void,
  ): void {
    try {
      const expiry = sessionData.cookie.expires
        ? new Date(sessionData.cookie.expires).getTime()
        : Date.now() + (sessionData.cookie.maxAge ?? 7 * 24 * 60 * 60 * 1000);
      this.touchStatement.run(expiry, sid);
      callback?.(null);
    } catch (error) {
      callback?.(
        error instanceof Error ? error : new Error("Session update failed."),
      );
    }
  }
}

export function withTransaction<T>(action: () => T): T {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = action();
    db.exec("COMMIT");
    return result;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}
