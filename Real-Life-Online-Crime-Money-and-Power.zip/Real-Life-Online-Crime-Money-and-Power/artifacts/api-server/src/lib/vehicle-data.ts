import {
  GetGarageResponse,
  ListVehiclesResponse,
  PurchaseVehicleResponse,
  SetActiveVehicleResponse,
} from "@workspace/api-zod";
import type { Player } from "@workspace/api-zod";
import { db } from "./sqlite";

export type VehicleCatalogRecord = {
  id: string;
  name: string;
  category: string;
  description: string;
  price: number;
};

export type PlayerVehicleRecord = {
  id: number;
  vehicle_id: string;
  name: string;
  category: string;
  purchase_price: number;
  ownership_status: "owned";
  purchased_at: string;
  is_active: number;
};

const playerVehicleSelect = `
  SELECT pv.id, pv.vehicle_id, vc.name, vc.category, pv.purchase_price,
         pv.ownership_status, pv.purchased_at, pv.is_active
  FROM player_vehicles pv
  JOIN vehicle_catalog vc ON vc.id = pv.vehicle_id
`;

export function findVehicle(id: string): VehicleCatalogRecord | undefined {
  return db
    .prepare(
      "SELECT id, name, category, description, price FROM vehicle_catalog WHERE id = ?",
    )
    .get(id) as VehicleCatalogRecord | undefined;
}

export function listVehicles(playerId: number) {
  const rows = db
    .prepare(
      `SELECT vc.id, vc.name, vc.category, vc.description, vc.price,
              EXISTS(
                SELECT 1 FROM player_vehicles pv
                WHERE pv.player_id = ? AND pv.vehicle_id = vc.id
              ) AS owned
       FROM vehicle_catalog vc ORDER BY vc.price ASC`,
    )
    .all(playerId) as (VehicleCatalogRecord & { owned: number })[];
  return ListVehiclesResponse.parse(
    rows.map((vehicle) => ({ ...vehicle, owned: vehicle.owned === 1 })),
  );
}

export function toPlayerVehicle(vehicle: PlayerVehicleRecord) {
  return SetActiveVehicleResponse.parse({
    id: vehicle.id,
    vehicleId: vehicle.vehicle_id,
    name: vehicle.name,
    category: vehicle.category,
    purchasePrice: vehicle.purchase_price,
    ownershipStatus: vehicle.ownership_status,
    purchasedAt: vehicle.purchased_at,
    isActive: vehicle.is_active === 1,
  });
}

export function findPlayerVehicle(
  playerId: number,
  vehicleRecordId: number,
): PlayerVehicleRecord | undefined {
  return db
    .prepare(
      `${playerVehicleSelect}
       WHERE pv.id = ? AND pv.player_id = ?`,
    )
    .get(vehicleRecordId, playerId) as PlayerVehicleRecord | undefined;
}

export function findPlayerVehicleByPurchaseRequest(
  playerId: number,
  purchaseRequestId: string,
): PlayerVehicleRecord | undefined {
  return db
    .prepare(
      `${playerVehicleSelect}
       WHERE pv.player_id = ? AND pv.purchase_request_id = ?`,
    )
    .get(playerId, purchaseRequestId) as PlayerVehicleRecord | undefined;
}

export function listPlayerVehicles(playerId: number) {
  return db
    .prepare(
      `${playerVehicleSelect}
       WHERE pv.player_id = ?
       ORDER BY pv.is_active DESC, pv.id ASC`,
    )
    .all(playerId) as PlayerVehicleRecord[];
}

export function getGarage(playerId: number) {
  const vehicles = listPlayerVehicles(playerId).map(toPlayerVehicle);
  return GetGarageResponse.parse({
    vehicles,
    activeVehicleId: vehicles.find((vehicle) => vehicle.isActive)?.id ?? null,
  });
}

export function toPurchaseResult(
  player: Player,
  vehicle: PlayerVehicleRecord,
  replayed: boolean,
) {
  return PurchaseVehicleResponse.parse({
    player,
    vehicle: toPlayerVehicle(vehicle),
    replayed,
  });
}
