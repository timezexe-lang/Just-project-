import {
  GetCurrentPlayerResponse,
  ListJobsResponse,
} from "@workspace/api-zod";
import { db } from "./sqlite";

export type PlayerRecord = {
  id: number;
  username: string;
  password_hash: string;
  cash: number;
  bank_balance: number;
  level: number;
  experience: number;
  health: number;
  energy: number;
  reputation: number;
  wanted_level: number;
  current_job: string | null;
  last_work_at: number | null;
  created_at: string;
};

export function findPlayerById(id: number): PlayerRecord | undefined {
  return db
    .prepare("SELECT * FROM players WHERE id = ?")
    .get(id) as PlayerRecord | undefined;
}

export function findPlayerByUsername(username: string): PlayerRecord | undefined {
  return db
    .prepare("SELECT * FROM players WHERE username = ?")
    .get(username) as PlayerRecord | undefined;
}

export function toPlayer(player: PlayerRecord) {
  return GetCurrentPlayerResponse.parse({
    id: player.id,
    username: player.username,
    cash: player.cash,
    bankBalance: player.bank_balance,
    level: player.level,
    experience: player.experience,
    health: player.health,
    energy: player.energy,
    reputation: player.reputation,
    wantedLevel: player.wanted_level,
    currentJob: player.current_job,
    createdAt: player.created_at,
  });
}

export type JobRecord = {
  id: string;
  title: string;
  district: string;
  salary: number;
  energy_cost: number;
  description: string;
};

export function findJob(id: string): JobRecord | undefined {
  return db.prepare("SELECT * FROM jobs WHERE id = ?").get(id) as
    | JobRecord
    | undefined;
}

export function listJobs() {
  const rows = db
    .prepare("SELECT * FROM jobs ORDER BY salary ASC")
    .all() as JobRecord[];
  return ListJobsResponse.parse(
    rows.map((job) => ({
      id: job.id,
      title: job.title,
      district: job.district,
      salary: job.salary,
      energyCost: job.energy_cost,
      description: job.description,
    })),
  );
}

export function toJob(job: JobRecord) {
  return {
    id: job.id,
    title: job.title,
    district: job.district,
    salary: job.salary,
    energyCost: job.energy_cost,
    description: job.description,
  };
}

export function addActivity(
  playerId: number,
  kind: string,
  description: string,
  amount: number | null,
): void {
  db.prepare(
    "INSERT INTO activities (player_id, kind, description, amount, created_at) VALUES (?, ?, ?, ?, ?)",
  ).run(playerId, kind, description, amount, new Date().toISOString());
}

export function listActivities(playerId: number) {
  return db
    .prepare(
      `SELECT id, kind, description, amount, created_at AS createdAt
       FROM activities WHERE player_id = ? ORDER BY id DESC LIMIT 8`,
    )
    .all(playerId)
    .map((activity) => {
      const row = activity as {
        id: number;
        kind: string;
        description: string;
        amount: number | null;
        createdAt: string;
      };
      return {
        id: row.id,
        kind: row.kind,
        description: row.description,
        amount: row.amount,
        createdAt: row.createdAt,
      };
    });
}
