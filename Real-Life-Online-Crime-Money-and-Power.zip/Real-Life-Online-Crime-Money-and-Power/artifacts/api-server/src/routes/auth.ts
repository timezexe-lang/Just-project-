import { Router, type IRouter, type Request } from "express";
import bcrypt from "bcryptjs";
import rateLimit from "express-rate-limit";
import {
  LoginPlayerBody,
  LoginPlayerResponse,
  LogoutPlayerResponse,
  RegisterPlayerBody,
  RegisterPlayerResponse,
} from "@workspace/api-zod";
import { addActivity, findPlayerByUsername, findPlayerById, toPlayer } from "../lib/game-data";
import { db } from "../lib/sqlite";

const router: IRouter = Router();
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many attempts. Please wait a few minutes and try again." },
});

function regenerateSession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => {
      if (error) reject(error);
      else resolve();
    });
  });
}

function saveSession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    req.session.save((error) => {
      if (error) reject(error);
      else resolve();
    });
  });
}

router.post("/auth/register", authLimiter, async (req, res): Promise<void> => {
  const parsed = RegisterPlayerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a username and a password of at least 10 characters." });
    return;
  }

  const username = parsed.data.username.trim();
  if (Buffer.byteLength(parsed.data.password, "utf8") > 72) {
    res.status(400).json({ error: "Password must be no longer than 72 bytes." });
    return;
  }

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  const now = new Date().toISOString();
  try {
    const result = db
      .prepare(
        `INSERT INTO players (username, password_hash, cash, bank_balance, created_at)
         VALUES (?, ?, 10000, 20000, ?)`,
      )
      .run(username, passwordHash, now);
    const playerId = Number(result.lastInsertRowid);
    addActivity(playerId, "welcome", "Welcome to Port Meridian.", null);

    await regenerateSession(req);
    req.session.playerId = playerId;
    await saveSession(req);

    const player = findPlayerById(playerId);
    if (!player) {
      res.status(500).json({ error: "Your account was created, but could not be loaded." });
      return;
    }
    res.status(201).json(RegisterPlayerResponse.parse(toPlayer(player)));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes("UNIQUE constraint failed: players.username")
    ) {
      res.status(409).json({ error: "That username is already in use." });
      return;
    }
    throw error;
  }
});

router.post("/auth/login", authLimiter, async (req, res): Promise<void> => {
  const parsed = LoginPlayerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a valid username and password." });
    return;
  }
  if (Buffer.byteLength(parsed.data.password, "utf8") > 72) {
    res.status(401).json({ error: "Username or password is incorrect." });
    return;
  }

  const player = findPlayerByUsername(parsed.data.username.trim());
  const isValid = player
    ? await bcrypt.compare(parsed.data.password, player.password_hash)
    : false;
  if (!player || !isValid) {
    res.status(401).json({ error: "Username or password is incorrect." });
    return;
  }

  await regenerateSession(req);
  req.session.playerId = player.id;
  await saveSession(req);
  res.json(LoginPlayerResponse.parse(toPlayer(player)));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  await new Promise<void>((resolve, reject) => {
    req.session.destroy((error) => {
      if (error) reject(error);
      else resolve();
    });
  });
  res.clearCookie("rlo.sid", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
  });
  res.json(LogoutPlayerResponse.parse({ message: "Signed out." }));
});

router.get("/auth/me", (req, res): void => {
  const playerId = req.session.playerId;
  const player = playerId ? findPlayerById(playerId) : undefined;
  if (!player) {
    res.status(401).json({ error: "Sign in to continue." });
    return;
  }
  res.json(toPlayer(player));
});

export default router;
