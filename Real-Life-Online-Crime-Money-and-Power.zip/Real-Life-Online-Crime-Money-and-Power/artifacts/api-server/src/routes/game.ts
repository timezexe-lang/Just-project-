import { Router, type IRouter } from "express";
import {
  CreateBankTransactionBody,
  GetGameDashboardResponse,
  WorkJobShiftParams,
  WorkJobShiftResponse,
} from "@workspace/api-zod";
import {
  addActivity,
  findJob,
  findPlayerById,
  listActivities,
  listJobs,
  toJob,
  toPlayer,
} from "../lib/game-data";
import { db, withTransaction } from "../lib/sqlite";

const router: IRouter = Router();
const SHIFT_COOLDOWN_MS = 15_000;

const features = [
  {
    id: "jobs",
    title: "Jobs & salaries",
    status: "available" as const,
    description: "Choose a city job and earn a salary for each shift.",
  },
  {
    id: "bank",
    title: "City bank",
    status: "available" as const,
    description: "Move money safely between your wallet and bank account.",
  },
  {
    id: "vehicles",
    title: "Vehicle dealership",
    status: "available" as const,
    description: "Buy vehicles with cash and manage your personal garage.",
  },
  {
    id: "properties",
    title: "Homes & properties",
    status: "coming_soon" as const,
    description: "Find a place to live and grow your property portfolio.",
  },
  {
    id: "businesses",
    title: "Businesses",
    status: "coming_soon" as const,
    description: "Own a local business and build a steady income.",
  },
  {
    id: "city-hall",
    title: "Police, crime & government",
    status: "coming_soon" as const,
    description: "Take part in the city's law, crime and civic roleplay.",
  },
];

function getSignedInPlayer(req: Parameters<Parameters<IRouter["get"]>[1]>[0]) {
  const id = req.session.playerId;
  return id ? findPlayerById(id) : undefined;
}

function requirePlayer(
  req: Parameters<Parameters<IRouter["get"]>[1]>[0],
  res: Parameters<Parameters<IRouter["get"]>[1]>[1],
) {
  const player = getSignedInPlayer(req);
  if (!player) {
    res.status(401).json({ error: "Sign in to continue." });
    return undefined;
  }
  return player;
}

router.get("/game/dashboard", (req, res): void => {
  const player = requirePlayer(req, res);
  if (!player) return;

  res.json(
    GetGameDashboardResponse.parse({
      player: toPlayer(player),
      jobs: listJobs(),
      activities: listActivities(player.id),
      features,
    }),
  );
});

router.get("/jobs", (req, res): void => {
  const player = requirePlayer(req, res);
  if (!player) return;
  res.json(listJobs());
});

router.post("/jobs/:jobId/work", (req, res): void => {
  const params = WorkJobShiftParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Choose a valid job." });
    return;
  }
  const player = requirePlayer(req, res);
  if (!player) return;

  const job = findJob(params.data.jobId);
  if (!job) {
    res.status(404).json({ error: "That job is not available." });
    return;
  }

  const now = Date.now();
  if (player.last_work_at && now - player.last_work_at < SHIFT_COOLDOWN_MS) {
    res.status(409).json({ error: "Your next shift is not ready yet. Take a short break." });
    return;
  }
  if (player.energy < job.energy_cost) {
    res.status(409).json({ error: "You need more energy before starting this shift." });
    return;
  }

  withTransaction(() => {
    db.prepare(
      `UPDATE players
       SET cash = cash + ?, energy = energy - ?, experience = experience + ?,
           level = 1 + CAST((experience + ?) / 100 AS INTEGER),
           current_job = ?, last_work_at = ?
       WHERE id = ?`,
    ).run(job.salary, job.energy_cost, 25, 25, job.title, now, player.id);
    addActivity(
      player.id,
      "salary",
      `Completed a shift as ${job.title}.`,
      job.salary,
    );
  });

  const updatedPlayer = findPlayerById(player.id);
  if (!updatedPlayer) {
    res.status(500).json({ error: "Your player profile could not be loaded." });
    return;
  }
  res.json(
    WorkJobShiftResponse.parse({
      player: toPlayer(updatedPlayer),
      job: toJob(job),
      salary: job.salary,
      nextShiftAt: new Date(now + SHIFT_COOLDOWN_MS).toISOString(),
    }),
  );
});

router.post("/bank/transactions", (req, res): void => {
  const parsed = CreateBankTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a whole-dollar amount between $1 and $1,000,000." });
    return;
  }
  const player = requirePlayer(req, res);
  if (!player) return;
  const { type, amount } = parsed.data;

  const balance = type === "deposit" ? player.cash : player.bank_balance;
  if (amount > balance) {
    res.status(409).json({
      error: type === "deposit" ? "You do not have enough cash." : "Your bank balance is too low.",
    });
    return;
  }

  withTransaction(() => {
    if (type === "deposit") {
      db.prepare(
        "UPDATE players SET cash = cash - ?, bank_balance = bank_balance + ? WHERE id = ?",
      ).run(amount, amount, player.id);
    } else {
      db.prepare(
        "UPDATE players SET cash = cash + ?, bank_balance = bank_balance - ? WHERE id = ?",
      ).run(amount, amount, player.id);
    }
    addActivity(
      player.id,
      type,
      `${type === "deposit" ? "Deposited" : "Withdrew"} $${amount.toLocaleString()} ${type === "deposit" ? "into" : "from"} the bank.`,
      amount,
    );
  });

  const updatedPlayer = findPlayerById(player.id);
  if (!updatedPlayer) {
    res.status(500).json({ error: "Your player profile could not be loaded." });
    return;
  }
  res.json(toPlayer(updatedPlayer));
});

export default router;
