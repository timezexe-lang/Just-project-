import { Router, type IRouter } from "express";
import { PurchaseVehicleBody, SetActiveVehicleBody } from "@workspace/api-zod";
import { addActivity, findPlayerById, toPlayer } from "../lib/game-data";
import { db, withTransaction } from "../lib/sqlite";
import {
  findPlayerVehicle,
  findPlayerVehicleByPurchaseRequest,
  findVehicle,
  getGarage,
  listVehicles,
  toPlayerVehicle,
  toPurchaseResult,
} from "../lib/vehicle-data";

const router: IRouter = Router();

function requirePlayer(
  req: Parameters<Parameters<IRouter["get"]>[1]>[0],
  res: Parameters<Parameters<IRouter["get"]>[1]>[1],
) {
  const playerId = req.session.playerId;
  const player = playerId ? findPlayerById(playerId) : undefined;
  if (!player) {
    res.status(401).json({ error: "Sign in to continue." });
    return undefined;
  }
  return player;
}

router.get("/vehicles", (req, res): void => {
  const player = requirePlayer(req, res);
  if (!player) return;
  res.json(listVehicles(player.id));
});

router.post("/vehicles/purchase", (req, res): void => {
  const parsedBody = PurchaseVehicleBody.safeParse(req.body);
  if (!parsedBody.success) {
    res.status(400).json({ error: "Choose a valid vehicle from the dealership." });
    return;
  }
  if (
    typeof req.body === "object" &&
    req.body !== null &&
    Object.keys(req.body).some(
      (key) => key !== "vehicleId" && key !== "idempotencyKey",
    )
  ) {
    res.status(400).json({ error: "Prices and other purchase fields are set by the city." });
    return;
  }
  const player = requirePlayer(req, res);
  if (!player) return;

  const vehicle = findVehicle(parsedBody.data.vehicleId);
  if (!vehicle) {
    res.status(404).json({ error: "That vehicle is no longer available." });
    return;
  }

  const requestId = parsedBody.data.idempotencyKey;
  const result = withTransaction(() => {
    const priorPurchase = findPlayerVehicleByPurchaseRequest(player.id, requestId);
    if (priorPurchase) {
      if (priorPurchase.vehicle_id !== vehicle.id) {
        return { status: "key-conflict" as const };
      }
      const currentPlayer = findPlayerById(player.id);
      if (!currentPlayer) return { status: "player-missing" as const };
      return {
        status: "replayed" as const,
        player: toPlayer(currentPlayer),
        vehicle: priorPurchase,
      };
    }

    const alreadyOwned = db
      .prepare(
        "SELECT id FROM player_vehicles WHERE player_id = ? AND vehicle_id = ?",
      )
      .get(player.id, vehicle.id);
    if (alreadyOwned) return { status: "already-owned" as const };

    const debit = db
      .prepare("UPDATE players SET cash = cash - ? WHERE id = ? AND cash >= ?")
      .run(vehicle.price, player.id, vehicle.price);
    if (debit.changes !== 1) return { status: "insufficient-funds" as const };

    const isFirstVehicle =
      (db
        .prepare("SELECT 1 AS found FROM player_vehicles WHERE player_id = ? LIMIT 1")
        .get(player.id) as { found: number } | undefined) === undefined;
    const purchasedAt = new Date().toISOString();
    const insert = db
      .prepare(
        `INSERT INTO player_vehicles
          (player_id, vehicle_id, purchase_price, ownership_status, purchased_at, is_active, purchase_request_id)
         VALUES (?, ?, ?, 'owned', ?, ?, ?)`,
      )
      .run(
        player.id,
        vehicle.id,
        vehicle.price,
        purchasedAt,
        isFirstVehicle ? 1 : 0,
        requestId,
      );
    addActivity(
      player.id,
      "vehicle-purchase",
      `Purchased a ${vehicle.name}.`,
      -vehicle.price,
    );

    const purchasedVehicle = findPlayerVehicle(player.id, Number(insert.lastInsertRowid));
    const currentPlayer = findPlayerById(player.id);
    if (!purchasedVehicle || !currentPlayer) return { status: "player-missing" as const };
    return {
      status: "purchased" as const,
      player: toPlayer(currentPlayer),
      vehicle: purchasedVehicle,
    };
  });

  if (result.status === "insufficient-funds") {
    res.status(409).json({ error: "You do not have enough cash for that vehicle." });
    return;
  }
  if (result.status === "key-conflict") {
    res.status(409).json({ error: "This purchase request was already used for another vehicle." });
    return;
  }
  if (result.status === "already-owned") {
    res.status(409).json({ error: "You already own this vehicle. Visit your garage to view it." });
    return;
  }
  if (result.status === "player-missing") {
    res.status(500).json({ error: "Your player profile could not be loaded." });
    return;
  }

  res
    .status(result.status === "replayed" ? 200 : 201)
    .json(toPurchaseResult(result.player, result.vehicle, result.status === "replayed"));
});

router.get("/garage", (req, res): void => {
  const player = requirePlayer(req, res);
  if (!player) return;
  res.json(getGarage(player.id));
});

router.put("/garage/active-vehicle", (req, res): void => {
  const parsed = SetActiveVehicleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a valid vehicle from your garage." });
    return;
  }
  const player = requirePlayer(req, res);
  if (!player) return;

  const vehicle = findPlayerVehicle(player.id, parsed.data.vehicleRecordId);
  if (!vehicle) {
    res.status(404).json({ error: "That vehicle is not in your garage." });
    return;
  }

  withTransaction(() => {
    db.prepare("UPDATE player_vehicles SET is_active = 0 WHERE player_id = ?").run(
      player.id,
    );
    db.prepare(
      "UPDATE player_vehicles SET is_active = 1 WHERE id = ? AND player_id = ?",
    ).run(vehicle.id, player.id);
  });

  const activeVehicle = findPlayerVehicle(player.id, vehicle.id);
  if (!activeVehicle) {
    res.status(500).json({ error: "Your active vehicle could not be loaded." });
    return;
  }
  res.json(toPlayerVehicle(activeVehicle));
});

export default router;
