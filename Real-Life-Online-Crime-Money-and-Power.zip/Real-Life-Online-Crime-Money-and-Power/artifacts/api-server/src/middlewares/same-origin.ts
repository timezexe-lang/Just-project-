import type { RequestHandler } from "express";

const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);

export const requireSameOriginForMutations: RequestHandler = (
  req,
  res,
  next,
) => {
  if (!MUTATING_METHODS.has(req.method)) {
    next();
    return;
  }

  const origin = req.get("origin");
  if (!origin) {
    next();
    return;
  }

  try {
    const originUrl = new URL(origin);
    const forwardedHost = req.get("x-forwarded-host")?.split(",")[0]?.trim();
    const host = forwardedHost || req.get("host");
    const forwardedProto = req
      .get("x-forwarded-proto")
      ?.split(",")[0]
      ?.trim();
    const protocol = forwardedProto || req.protocol;

    if (!host || originUrl.origin !== `${protocol}://${host}`) {
      res.status(403).json({ error: "Request origin is not allowed." });
      return;
    }
  } catch {
    res.status(403).json({ error: "Request origin is not allowed." });
    return;
  }

  next();
};
