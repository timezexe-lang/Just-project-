---
name: SQLite runtime in this Repl
description: Keep the SQLite driver compatible with this workspace's Node runtime and package install policy.
---

Use Node 24's built-in `node:sqlite` for SQLite in this Repl. Native add-on install scripts such as the one required by `better-sqlite3` are ignored by pnpm unless explicitly approved.

**Why:** the native driver installed without its build script, while Node 24 already provides SQLite without a separate compile step.

**How to apply:** keep the API workflow on Node 24 and verify `node:sqlite` is available before changing the SQLite driver.
